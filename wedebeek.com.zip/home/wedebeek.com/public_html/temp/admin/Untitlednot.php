border-color: #212121 -moz-use-text-color #0a0c0e; the li a
.nav-tabs.nav-stacked > li > a  nav-tabs.nav-stacked la class ul
.nav-stacked tuong ung voi
.nav-tabs.nav-stacked > li.active > a

ifx ie
.sidebar-nav > ul > li > ul ben kia tuong ung voi menuleft