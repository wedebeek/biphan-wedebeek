<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8" />
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <link rel="stylesheet" type="text/css" href="<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/fonts/MyFontsWebfontsKit.css">
      <!--link rel="stylesheet" href="<?php echo base_url('temp/default/home_site');?>/use.typekit.net/dry1ujl.css"-->
      <link rel="stylesheet" href="<?php echo base_url('temp/default/home_site');?>/use.fontawesome.com/releases/v5.7.2/css/all.css" crossorigin="anonymous">
      <!--  Mobile viewport scale -->
      <meta name="viewport" content="width=device-width, initial-scale=1"/>
      <title>Wedebeek | Performance Marketing Network</title>
      <meta name="description" content="Wedebeek unifies the smartest players in the affiliate marketing business, especially those in Dating, Nutra and Mainstream." />
      <link rel='stylesheet' id='toolset-common-es-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/wp-views/vendor/toolset/common-es/public/toolset-common-esb9f0.css?ver=126000' type='text/css' media='all' />
      <link rel='stylesheet' id='toolset_blocks-style-css-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/wp-views/vendor/toolset/blocks/public/css/style9632.css?ver=1.2.3' type='text/css' media='all' />
      <link rel='stylesheet' id='wp-block-library-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-includes/css/dist/block-library/style.min03ec.css?ver=5.3.4' type='text/css' media='all' />
      <link rel='stylesheet' id='view_editor_gutenberg_frontend_assets-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/wp-views/public/css/views-frontenddeae.css?ver=3.2.1' type='text/css' media='all' />
      <link rel='stylesheet' id='responsive-lightbox-swipebox-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/responsive-lightbox/assets/swipebox/swipebox.min950a.css?ver=2.2.3' type='text/css' media='all' />
      <link rel='stylesheet' id='siteorigin-panels-front-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/siteorigin-panels/css/front-flex.min6af1.css?ver=2.11.0' type='text/css' media='all' />
      <link rel='stylesheet' id='jquery-background-video-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/video-backgrounds-for-siteorigin-page-builder/assets/jquery.background-video03ec.css?ver=5.3.4' type='text/css' media='all' />
      <link rel='stylesheet' id='so_video_background-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/video-backgrounds-for-siteorigin-page-builder/assets/so_video_background03ec.css?ver=5.3.4' type='text/css' media='all' />
      <link rel='stylesheet' id='canvas-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas/style03ec.css?ver=5.3.4' type='text/css' media='all' />
      <link rel='stylesheet' id='slick-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/slick03ec.css?ver=5.3.4' type='text/css' media='all' />
      <link rel='stylesheet' id='slick-theme-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/slick-theme03ec.css?ver=5.3.4' type='text/css' media='all' />
      <link rel='stylesheet' id='toolset_bootstrap_styles-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/wp-views/vendor/toolset/toolset-common/res/lib/bootstrap3/css/bootstrapa7a0.css?ver=3.6.1' type='text/css' media='screen' />
      <link rel='stylesheet' id='mediaelement-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/mediaelement/mediaelementplayer-legacy.minc270.css?ver=4.2.13-9993131' type='text/css' media='all' />
      <link rel='stylesheet' id='wp-mediaelement-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/mediaelement/wp-mediaelement.min03ec.css?ver=5.3.4' type='text/css' media='all' />
      <link rel='stylesheet' id='views-pagination-style-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/wp-views/embedded/res/css/wpv-paginationdeae.css?ver=3.2.1' type='text/css' media='all' />
      <style id='views-pagination-style-inline-css' type='text/css'>
         .wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-default > span.wpv-sort-list,.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-default .wpv-sort-list-item {border-color: #cdcdcd;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-default .wpv-sort-list-item a {color: #444;background-color: #fff;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-default a:hover,.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-default a:focus {color: #000;background-color: #eee;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-default .wpv-sort-list-item.wpv-sort-list-current a {color: #000;background-color: #eee;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-grey > span.wpv-sort-list,.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-grey .wpv-sort-list-item {border-color: #cdcdcd;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-grey .wpv-sort-list-item a {color: #444;background-color: #eeeeee;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-grey a:hover,.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-grey a:focus {color: #000;background-color: #e5e5e5;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-grey .wpv-sort-list-item.wpv-sort-list-current a {color: #000;background-color: #e5e5e5;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-blue > span.wpv-sort-list,.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-blue .wpv-sort-list-item {border-color: #0099cc;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-blue .wpv-sort-list-item a {color: #444;background-color: #cbddeb;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-blue a:hover,.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-blue a:focus {color: #000;background-color: #95bedd;}.wpv-sort-list-dropdown.wpv-sort-list-dropdown-style-blue .wpv-sort-list-item.wpv-sort-list-current a {color: #000;background-color: #95bedd;}
      </style>
      <link rel='stylesheet' id='theme-stylesheet-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/stylef269.css?ver=1.0.1' type='text/css' media='all' />
      <link rel='stylesheet' id='ubermenu-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/ubermenu/pro/assets/css/ubermenu.min2c3d.css?ver=3.2.7' type='text/css' media='all' />
      <link rel='stylesheet' id='ubermenu-black-white-2-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/ubermenu/assets/css/skins/blackwhite203ec.css?ver=5.3.4' type='text/css' media='all' />
      <link rel='stylesheet' id='ubermenu-font-awesome-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/ubermenu/assets/css/fontawesome/css/font-awesome.mind7b7.css?ver=4.3' type='text/css' media='all' />
      <link rel='stylesheet' id='woo-gravity-forms-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas/includes/integrations/gravity-forms/css/gravity-forms03ec.css?ver=5.3.4' type='text/css' media='all' />
      <!--[if lt IE 9]>
      <link href="<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas/css/non-responsive.css" rel="stylesheet" type="text/css" />
      <style type="text/css">.col-full, #wrapper { width: 1200px; max-width: 1200px; } #inner-wrapper { padding: 0; } body.full-width #header, #nav-container, body.full-width #content, body.full-width #footer-widgets, body.full-width #footer { padding-left: 0; padding-right: 0; } body.fixed-mobile #top, body.fixed-mobile #header-container, body.fixed-mobile #footer-container, body.fixed-mobile #nav-container, body.fixed-mobile #footer-widgets-container { min-width: 1200px; padding: 0 1em; } body.full-width #content { width: auto; padding: 0 1em;}</style>
      <![endif]-->
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/wp-views/vendor/toolset/common-es/public/toolset-common-es-masonry03ec.js?ver=5.3.4'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/jquery/jquery4a5f.js?ver=1.12.4-wp'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/handl-utm-grabber/js/js.cookie03ec.js?ver=5.3.4'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var handl_utm = [];
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/handl-utm-grabber/js/handl-utm-grabber03ec.js?ver=5.3.4'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/responsive-lightbox/assets/swipebox/jquery.swipebox.min950a.js?ver=2.2.3'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/responsive-lightbox/assets/infinitescroll/infinite-scroll.pkgd.min03ec.js?ver=5.3.4'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var rlArgs = {"script":"swipebox","selector":"lightbox","customEvents":"","activeGalleries":"0","animation":"1","hideCloseButtonOnMobile":"0","removeBarsOnMobile":"0","hideBars":"1","hideBarsDelay":"5000","videoMaxWidth":"1080","useSVG":"1","loopAtEnd":"1","woocommerce_gallery":"0","ajaxurl":"#","nonce":"6881afa7a4"};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/responsive-lightbox/js/front950a.js?ver=2.2.3'></script>
  
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas/includes/js/third-party.min03ec.js?ver=5.3.4'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas/includes/js/modernizr.min61da.js?ver=2.6.2'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas/includes/js/general.min03ec.js?ver=5.3.4'></script>
      <!-- Adjust the website width -->
      <style type="text/css">
         .col-full, #wrapper { max-width: 1200px !important; }
      </style>
      <style>[class$="woocommerce-product-gallery__trigger"] {visibility:hidden;}</style>
      <!-- DO NOT COPY THIS SNIPPET! Start of Page Analytics Tracking for HubSpot WordPress plugin v7.33.3-->
      <script type="text/javascript">
         var _hsq = _hsq || [];
         _hsq.push(["setContentType", "standard-page"]);
      </script>
      <!-- DO NOT COPY THIS SNIPPET! End of Page Analytics Tracking for HubSpot WordPress plugin -->
      <style id="ubermenu-custom-generated-css">
         /** UberMenu Custom Menu Styles (Customizer) **/
         /* main_menu */
         .ubermenu-main_menu.ubermenu-transition-fade .ubermenu-item .ubermenu-submenu-drop { margin-top:0; }
         .ubermenu-main_menu .ubermenu-item-level-0 > .ubermenu-target { font-size:15px; text-transform:uppercase; color:#ffffff; }
         .ubermenu.ubermenu-main_menu .ubermenu-item-level-0:hover > .ubermenu-target, .ubermenu-main_menu .ubermenu-item-level-0.ubermenu-active > .ubermenu-target { color:#ffffff; }
         .ubermenu-main_menu .ubermenu-item-level-0.ubermenu-current-menu-item > .ubermenu-target, .ubermenu-main_menu .ubermenu-item-level-0.ubermenu-current-menu-parent > .ubermenu-target, .ubermenu-main_menu .ubermenu-item-level-0.ubermenu-current-menu-ancestor > .ubermenu-target { color:#193cd2; }
         .ubermenu-main_menu .ubermenu-item.ubermenu-item-level-0 > .ubermenu-highlight { color:#111111; }
         .ubermenu-main_menu .ubermenu-item-level-0 > .ubermenu-target, .ubermenu-main_menu .ubermenu-item-level-0 > .ubermenu-custom-content.ubermenu-custom-content-padded { padding-top:39px; padding-bottom:39px; }
         .ubermenu-main_menu .ubermenu-submenu.ubermenu-submenu-drop { background-color:#ffffff; }
         .ubermenu-main_menu .ubermenu-item-normal > .ubermenu-target,.ubermenu-main_menu .ubermenu-submenu .ubermenu-target,.ubermenu-main_menu .ubermenu-submenu .ubermenu-nonlink,.ubermenu-main_menu .ubermenu-submenu .ubermenu-widget,.ubermenu-main_menu .ubermenu-submenu .ubermenu-custom-content-padded,.ubermenu-main_menu .ubermenu-submenu .ubermenu-retractor,.ubermenu-main_menu .ubermenu-submenu .ubermenu-colgroup .ubermenu-column,.ubermenu-main_menu .ubermenu-submenu.ubermenu-submenu-type-stack > .ubermenu-item-normal > .ubermenu-target,.ubermenu-main_menu .ubermenu-submenu.ubermenu-submenu-padded { padding:10px; }
         .ubermenu .ubermenu-grid-row { padding-right:10px; }
         .ubermenu .ubermenu-grid-row .ubermenu-target { padding-right:0; }
         .ubermenu-responsive-toggle.ubermenu-responsive-toggle-main_menu { color:#ffffff; }
         .ubermenu-responsive-toggle.ubermenu-responsive-toggle-main_menu:hover { color:#ffffff; }
         /* icon_menu */
         .ubermenu-icon_menu.ubermenu-transition-fade .ubermenu-item .ubermenu-submenu-drop { margin-top:0; }
         .ubermenu-icon_menu .ubermenu-item-level-0 > .ubermenu-target { font-size:18px; color:#ffffff; padding-left:10px; padding-right:10px; }
         .ubermenu.ubermenu-icon_menu .ubermenu-item-level-0:hover > .ubermenu-target, .ubermenu-icon_menu .ubermenu-item-level-0.ubermenu-active > .ubermenu-target { color:#30c1dd; }
         .ubermenu-icon_menu .ubermenu-item-level-0.ubermenu-current-menu-item > .ubermenu-target, .ubermenu-icon_menu .ubermenu-item-level-0.ubermenu-current-menu-parent > .ubermenu-target, .ubermenu-icon_menu .ubermenu-item-level-0.ubermenu-current-menu-ancestor > .ubermenu-target { color:#ffffff; }
         .ubermenu-icon_menu .ubermenu-item.ubermenu-item-level-0 > .ubermenu-highlight { color:#ffffff; }
         .ubermenu-icon_menu .ubermenu-item-level-0 > .ubermenu-target, .ubermenu-icon_menu .ubermenu-item-level-0 > .ubermenu-custom-content.ubermenu-custom-content-padded { padding-top:39px; padding-bottom:39px; }
         .ubermenu-icon_menu.ubermenu-sub-indicators .ubermenu-item-level-0.ubermenu-has-submenu-drop > .ubermenu-target:not(.ubermenu-noindicator) { padding-right:25px; }
         .ubermenu-icon_menu.ubermenu-sub-indicators .ubermenu-item-level-0.ubermenu-has-submenu-drop > .ubermenu-target.ubermenu-noindicator { padding-right:10px; }
         /* topmenu */
         .ubermenu-topmenu.ubermenu-transition-fade .ubermenu-item .ubermenu-submenu-drop { margin-top:0; }
         .ubermenu-topmenu .ubermenu-item-level-0 > .ubermenu-target { font-size:14px; color:#5d6162; }
         .ubermenu.ubermenu-topmenu .ubermenu-item-level-0:hover > .ubermenu-target, .ubermenu-topmenu .ubermenu-item-level-0.ubermenu-active > .ubermenu-target { color:#30c1dd; }
         .ubermenu-topmenu .ubermenu-item-level-0.ubermenu-current-menu-item > .ubermenu-target, .ubermenu-topmenu .ubermenu-item-level-0.ubermenu-current-menu-parent > .ubermenu-target, .ubermenu-topmenu .ubermenu-item-level-0.ubermenu-current-menu-ancestor > .ubermenu-target { color:#5d6162; }
         .ubermenu-topmenu .ubermenu-item.ubermenu-item-level-0 > .ubermenu-highlight { color:#5d6162; }
         .ubermenu-topmenu .ubermenu-item-level-0 > .ubermenu-target, .ubermenu-topmenu .ubermenu-item-level-0 > .ubermenu-custom-content.ubermenu-custom-content-padded { padding-top:8px; padding-bottom:8px; }
         /* Status: Loaded from Transient */
      </style>
      <!-- Custom CSS Styling -->
      <style type="text/css">
         body {background-repeat:no-repeat;background-position:top left;background-attachment:scroll;border-top:0px solid #000000;}
         a:link, a:visited, #loopedSlider a.flex-prev:hover, #loopedSlider a.flex-next:hover {color:#ffffff} .quantity .plus, .quantity .minus {background-color: #ffffff;}
         body #wrapper .button, body #wrapper #content .button, body #wrapper #content .button:visited, body #wrapper #content .reply a, body #wrapper #content #respond .form-submit input#submit, input[type=submit], body #wrapper #searchsubmit, #navigation ul.cart .button, body #wrapper .woo-sc-button {border: none; background:#ed0c6e}
         #header {background-repeat:no-repeat;background-position:left top;margin-top:0px;margin-bottom:0px;padding-top:0px;padding-bottom:0px;border:0px solid ;}
         #logo .site-title a {font:bold 40px/1em Arial, sans-serif;color:#ffffff;}
         #logo .site-description {font:300 13px/1em Arial, sans-serif;color:#999999;}
         #nav-container{border-top:0px solid #dbdbdb;border-bottom:0px solid #dbdbdb;border-left:none;border-right:none;}#nav-container #navigation ul#main-nav > li:first-child{border-left: 0px solid #dbdbdb;}#footer-widgets-container{background-color:#f0f0f0}#footer-widgets{border:none;}#footer-container{background-color:#222222}#footer-container{border-top:1px solid #dbdbdb;}#footer {border-width: 0 !important;}
         body, p { font:normal 18px/1.5em 'Roboto', arial, sans-serif;color:#000000; }
         h1 { font:bold 56px/1.2em 'Roboto', arial, sans-serif;color:#303035; }h2 { font:normal 56px/1.2em 'Roboto', arial, sans-serif;color:#000000; }h3 { font:bold 32px/1.2em 'Roboto', arial, sans-serif;color:#303035; }h4 { font:bold 22px/1.2em 'Roboto', arial, sans-serif;color:#303035; }h5 { font:bold 20px/1.2em 'Roboto', arial, sans-serif;color:#303035; }h6 { font:bold 12px/1.2em 'Roboto', arial, sans-serif;color:#303035; }
         .page-title, .post .title, .page .title {font:bold 20px/1.1em 'Roboto', arial, sans-serif;color:#323232;}
         .post .title a:link, .post .title a:visited, .page .title a:link, .page .title a:visited {color:#323232}
         .post-meta { font:300 12px/1.5em 'Roboto', arial, sans-serif;color:#666666; }
         .entry, .entry p{ font:300 15px/1.5em 'Roboto', arial, sans-serif;color:#666666; }
         .post-more {font:300 13px/1.5em Roboto;color:;border-top:0px solid #e6e6e6;border-bottom:0px solid #e6e6e6;}
         #post-author, #connect {border-top:0px solid #e6e6e6;border-bottom:0px solid #e6e6e6;border-left:0px solid #e6e6e6;border-right:0px solid #e6e6e6;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;background-color:#fafafa}
         .nav-entries a, .woo-pagination { font:300 13px/1em 'Roboto', arial, sans-serif;color:#888; }
         .woo-pagination a, .woo-pagination a:hover {color:#888!important}
         .widget h3 {font:bold 28px/1.2em Roboto;color:#44444c;border-bottom:0px solid #e6e6e6;margin-bottom:0;}
         .widget_recent_comments li, #twitter li { border-color: #e6e6e6;}
         .widget p, .widget .textwidget { font:300 18px/1.5em 'Roboto', arial, sans-serif;color:#747375; }
         .widget {font:300 18px/1.5em Roboto;color:#747375;border-radius:0px;-moz-border-radius:0px;-webkit-border-radius:0px;}
         #tabs .inside li a, .widget_woodojo_tabs .tabbable .tab-pane li a { font:bold 12px/1.5em 'Roboto', arial, sans-serif;color:#323232; }
         #tabs .inside li span.meta, .widget_woodojo_tabs .tabbable .tab-pane li span.meta { font:300 11px/1.5em 'Roboto', arial, sans-serif;color:#666666; }
         #tabs ul.wooTabs li a, .widget_woodojo_tabs .tabbable .nav-tabs li a { font:300 11px/2em 'Roboto', arial, sans-serif;color:#666666; }
         @media only screen and (min-width:768px) {
         ul.nav li a, #navigation ul.rss a, #navigation ul.cart a.cart-contents, #navigation .cart-contents #navigation ul.rss, #navigation ul.nav-search, #navigation ul.nav-search a { font:300 14px/1.2em 'Roboto', arial, sans-serif;color:#ffffff; } #navigation ul.rss li a:before, #navigation ul.nav-search a.search-contents:before { color:#ffffff;}
         #navigation ul.nav li ul, #navigation ul.cart > li > ul > div  { border: 0px solid #dbdbdb; }
         #navigation ul.nav > li:hover > ul  { left: 0; }
         #navigation ul.nav > li  { border-right: 0px solid #dbdbdb; }#navigation ul.nav > li:hover > ul  { left: 0; }
         #navigation { box-shadow: none; -moz-box-shadow: none; -webkit-box-shadow: none; }#navigation ul li:first-child, #navigation ul li:first-child a { border-radius:0px 0 0 0px; -moz-border-radius:0px 0 0 0px; -webkit-border-radius:0px 0 0 0px; }
         #navigation {border-top:0px solid #dbdbdb;border-bottom:0px solid #dbdbdb;border-left:0px solid #dbdbdb;border-right:0px solid #dbdbdb;border-radius:0px; -moz-border-radius:0px; -webkit-border-radius:0px;}
         #top ul.nav li a { font:300 12px/1.6em 'Roboto', arial, sans-serif;color:#3f3f3f; }
         #top ul.nav li.parent > a:after { border-top-color:#3f3f3f;}
         }
         #footer, #footer p { font:300 15px/1.4em Arial, sans-serif;color:#999999; }
         #footer {border-top:1px solid #dbdbdb;border-bottom:0px solid ;border-left:0px solid ;border-right:0px solid ;border-radius:0px; -moz-border-radius:0px; -webkit-border-radius:0px;}
         .magazine #loopedSlider .content h2.title a { font:bold 24px/1em Arial, sans-serif;color:#ffffff; }
         .wooslider-theme-magazine .slide-title a { font:bold 24px/1em Arial, sans-serif;color:#ffffff; }
         .magazine #loopedSlider .content .excerpt p { font:thin 13px/1.5em Arial, sans-serif;color:#cccccc; }
         .wooslider-theme-magazine .slide-content p, .wooslider-theme-magazine .slide-excerpt p { font:thin 13px/1.5em Arial, sans-serif;color:#cccccc; }
         .magazine .block .post .title a {font:bold 18px/1.2em Helvetica, Arial, sans-serif;color:#222222; }
         #loopedSlider.business-slider .content h2 { font:bold 24px/1em Arial, sans-serif;color:#ffffff; }
         #loopedSlider.business-slider .content h2.title a { font:bold 24px/1em Arial, sans-serif;color:#ffffff; }
         .wooslider-theme-business .has-featured-image .slide-title { font:bold 24px/1em Arial, sans-serif;color:#ffffff; }
         .wooslider-theme-business .has-featured-image .slide-title a { font:bold 24px/1em Arial, sans-serif;color:#ffffff; }
         #wrapper #loopedSlider.business-slider .content p { font:thin 13px/1.5em Arial, sans-serif;color:#cccccc; }
         .wooslider-theme-business .has-featured-image .slide-content p { font:thin 13px/1.5em Arial, sans-serif;color:#cccccc; }
         .wooslider-theme-business .has-featured-image .slide-excerpt p { font:thin 13px/1.5em Arial, sans-serif;color:#cccccc; }
         .archive_header { font:bold 18px/1em 'Roboto', arial, sans-serif;color:#323232; }
         .archive_header {border-bottom:0px solid #e6e6e6;}
         .archive_header .catrss { display:none; }
      </style>
      <!-- Custom Favicon -->     
      <link rel="apple-touch-icon" sizes="180x180" href="<?php echo base_url('temp/default/home_site');?>/favicon/apple-touch-icon.png">
      <link rel="icon" type="image/png" sizes="32x32" href="<?php echo base_url('temp/default/home_site');?>/favicon/favicon-32x32.png">
      <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url('temp/default/home_site');?>/favicon/favicon-16x16.png">
      <link rel="manifest" href="/site.webmanifest">
      <!-- Woo Shortcodes CSS -->
      <link href="<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas/functions/css/shortcodes.css" rel="stylesheet" type="text/css" />
      <!-- Custom Stylesheet -->
      <link href="<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas/custom9e25.css?1599309521" rel="stylesheet" type="text/css" />
      <!-- Custom Stylesheet In Child Theme -->
      <link href="<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/custom9e25.css?1599309521" rel="stylesheet" type="text/css" />
      
      <!-- Google Webfonts -->
      <link href="https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C300%2C300italic%2Cregular%2Citalic%2C500%2C500italic%2C700%2C700italic%2C900%2C900italic" rel="stylesheet" type="text/css" />
      <style type="text/css" media="all"
         id="siteorigin-panels-layouts-head">/* Layout 336 */ #pgc-336-0-0 { width:50.1804%;width:calc(50.1804% - ( 0.49819587628866 * 30px ) ) } #pgc-336-0-1 { width:49.8196%;width:calc(49.8196% - ( 0.50180412371134 * 30px ) ) } #pg-336-0 , #pg-336-1 , #pg-336-2 , #pg-336-3 , #pg-336-4 , #pg-336-5 , #pg-336-6 , #pg-336-7 , #pg-336-8 , #pg-336-9 , #pg-336-10 , #pg-336-11 , #pl-336 .so-panel , #pl-336 .so-panel:last-child { margin-bottom:0px } #pgc-336-1-0 { width:62.1777%;width:calc(62.1777% - ( 0.37822349570201 * 30px ) ) } #pgc-336-1-1 { width:37.8223%;width:calc(37.8223% - ( 0.62177650429799 * 30px ) ) } #pgc-336-2-0 , #pgc-336-9-0 , #pgc-336-10-0 , #pgc-336-11-0 { width:100%;width:calc(100% - ( 0 * 30px ) ) } #pgc-336-3-0 , #pgc-336-3-1 , #pgc-336-4-0 , #pgc-336-4-1 , #pgc-336-5-0 , #pgc-336-5-1 , #pgc-336-6-0 , #pgc-336-6-1 , #pgc-336-7-0 , #pgc-336-7-1 , #pgc-336-8-0 , #pgc-336-8-1 { width:50%;width:calc(50% - ( 0.5 * 30px ) ) } #pl-336 #panel-336-10-0-2 { margin:30px 30px 0px 30px } #pg-336-0> .panel-row-style { background-color:#000000;padding:150px 0px 150px 0px } #pg-336-0.panel-no-style, #pg-336-0.panel-has-style > .panel-row-style , #pg-336-6.panel-no-style, #pg-336-6.panel-has-style > .panel-row-style , #pg-336-11.panel-no-style, #pg-336-11.panel-has-style > .panel-row-style { -webkit-align-items:center;align-items:center } #pgc-336-0-0 , #pgc-336-0-1 , #pgc-336-1-1 , #pgc-336-4-0 , #pgc-336-4-1 , #pgc-336-5-0 { align-self:auto } #pg-336-1> .panel-row-style { background-color:#ffffff;padding:0px 0px 0px 0px } #pg-336-1.panel-no-style, #pg-336-1.panel-has-style > .panel-row-style , #pg-336-2.panel-no-style, #pg-336-2.panel-has-style > .panel-row-style , #pg-336-3.panel-no-style, #pg-336-3.panel-has-style > .panel-row-style , #pg-336-4.panel-no-style, #pg-336-4.panel-has-style > .panel-row-style , #pg-336-5.panel-no-style, #pg-336-5.panel-has-style > .panel-row-style , #pg-336-7.panel-no-style, #pg-336-7.panel-has-style > .panel-row-style , #pg-336-8.panel-no-style, #pg-336-8.panel-has-style > .panel-row-style , #pg-336-9.panel-no-style, #pg-336-9.panel-has-style > .panel-row-style , #pg-336-10.panel-no-style, #pg-336-10.panel-has-style > .panel-row-style { -webkit-align-items:flex-start;align-items:flex-start } #pgc-336-1-0> .panel-cell-style , #panel-336-6-1-1> .panel-widget-style , #panel-336-10-0-2> .panel-widget-style { padding:0px 0px 0px 0px } #pgc-336-1-0 , #pgc-336-7-0 , #pgc-336-8-0 , #pgc-336-9-0 { align-self:center } #panel-336-1-0-0> .panel-widget-style { padding:100px 100px 100px 100px } #pgc-336-1-1> .panel-cell-style { background-image:url(<?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2020/04/website-changes-img3.jpg);background-position:center center;background-size:cover;position:relative } #pg-336-2> .panel-row-style { background-color:#1a1a1a;padding:120px 0px 0px 0px;display: none } #pg-336-3> .panel-row-style { background-color:#1a1a1a;padding:100px 0px 100px 0px;position:relative;overflow:hidden } #pgc-336-3-0 { align-self:flex-start } #panel-336-3-1-0> .panel-widget-style { text-align: center } #pg-336-4> .panel-row-style { padding:120px 0px 120px 0px;background: linear-gradient(to right, #37b8eb 0%,#ed0c6e 96%) } #pgc-336-4-1> .panel-cell-style { text-align:center } #pg-336-5> .panel-row-style , #pg-336-10> .panel-row-style { background-color:#ffffff;padding:120px 0px 120px 0px } #pg-336-6> .panel-row-style { background-color:#1a1a1a;padding:60px 0px 120px 0px;position:relative;overflow:hidden } #panel-336-6-0-0> .panel-widget-style , #panel-336-9-0-0> .panel-widget-style { padding:40px 40px 40px 40px } #panel-336-6-1-0> .panel-widget-style { padding:40px 40px 40px 0px } #pg-336-7> .panel-row-style { background-color:#1a1a1a;padding:120px 0px 120px 0px;background: linear-gradient(to right, #37b8eb 0%,#ed0c6e 96%);display:none } #pgc-336-7-0> .panel-cell-style { padding:0px 50px 0px 50px } #pg-336-8> .panel-row-style { background-color:#1a1a1a;padding:50px 0px 50px 0px;display:none } #pg-336-9> .panel-row-style { background-color:#1a1a1a;background-image:url(<?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2020/01/koa-productservices-1920x1080.jpg);background-repeat:repeat;padding:8% 0% 8% 0% } #pg-336-11> .panel-row-style { background-color:#1a1a1a;padding:120px 0px 80px 0px } #panel-336-11-0-0> .panel-widget-style { padding:50px 0px 50px 0px } @media (max-width:780px){ #pg-336-0.panel-no-style, #pg-336-0.panel-has-style > .panel-row-style , #pg-336-1.panel-no-style, #pg-336-1.panel-has-style > .panel-row-style , #pg-336-2.panel-no-style, #pg-336-2.panel-has-style > .panel-row-style , #pg-336-3.panel-no-style, #pg-336-3.panel-has-style > .panel-row-style , #pg-336-4.panel-no-style, #pg-336-4.panel-has-style > .panel-row-style , #pg-336-5.panel-no-style, #pg-336-5.panel-has-style > .panel-row-style , #pg-336-6.panel-no-style, #pg-336-6.panel-has-style > .panel-row-style , #pg-336-7.panel-no-style, #pg-336-7.panel-has-style > .panel-row-style , #pg-336-8.panel-no-style, #pg-336-8.panel-has-style > .panel-row-style , #pg-336-9.panel-no-style, #pg-336-9.panel-has-style > .panel-row-style , #pg-336-10.panel-no-style, #pg-336-10.panel-has-style > .panel-row-style , #pg-336-11.panel-no-style, #pg-336-11.panel-has-style > .panel-row-style { -webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column } #pg-336-0 > .panel-grid-cell , #pg-336-0 > .panel-row-style > .panel-grid-cell , #pg-336-1 > .panel-grid-cell , #pg-336-1 > .panel-row-style > .panel-grid-cell , #pg-336-2 > .panel-grid-cell , #pg-336-2 > .panel-row-style > .panel-grid-cell , #pg-336-3 > .panel-grid-cell , #pg-336-3 > .panel-row-style > .panel-grid-cell , #pg-336-4 > .panel-grid-cell , #pg-336-4 > .panel-row-style > .panel-grid-cell , #pg-336-5 > .panel-grid-cell , #pg-336-5 > .panel-row-style > .panel-grid-cell , #pg-336-6 > .panel-grid-cell , #pg-336-6 > .panel-row-style > .panel-grid-cell , #pg-336-7 > .panel-grid-cell , #pg-336-7 > .panel-row-style > .panel-grid-cell , #pg-336-8 > .panel-grid-cell , #pg-336-8 > .panel-row-style > .panel-grid-cell , #pg-336-9 > .panel-grid-cell , #pg-336-9 > .panel-row-style > .panel-grid-cell , #pg-336-10 > .panel-grid-cell , #pg-336-10 > .panel-row-style > .panel-grid-cell , #pg-336-11 > .panel-grid-cell , #pg-336-11 > .panel-row-style > .panel-grid-cell { width:100%;margin-right:0 } #pgc-336-0-0 , #pgc-336-1-0 , #pgc-336-3-0 , #pgc-336-4-0 , #pgc-336-5-0 , #pgc-336-6-0 , #pgc-336-7-0 , #pgc-336-8-0 , #pl-336 .panel-grid .panel-grid-cell-mobile-last { margin-bottom:0px } #pl-336 .panel-grid-cell { padding:0 } #pl-336 .panel-grid .panel-grid-cell-empty { display:none } #pg-336-0> .panel-row-style { padding:70px 0px 70px 0px } #panel-336-0-0-0> .panel-widget-style { padding:50px 0px 0px 0px } #pg-336-1> .panel-row-style , #pgc-336-1-0> .panel-cell-style , #panel-336-6-0-0> .panel-widget-style , #panel-336-6-1-0> .panel-widget-style , #panel-336-9-0-0> .panel-widget-style { padding:0px 0px 0px 0px } #panel-336-1-0-0> .panel-widget-style { padding:50px 40px 50px 40px } #pg-336-2> .panel-row-style , #pg-336-3> .panel-row-style { padding:0px 0px 50px 0px } #pg-336-4> .panel-row-style , #pg-336-5> .panel-row-style , #pg-336-6> .panel-row-style , #pg-336-7> .panel-row-style , #pg-336-8> .panel-row-style , #pg-336-10> .panel-row-style { padding:50px 0px 50px 0px } #pgc-336-7-0> .panel-cell-style { padding:0px 15px 0px 15px } #pg-336-9> .panel-row-style { padding:20% 0% 20% 0% } #pg-336-11> .panel-row-style { padding:50px 0px 30px 0px } #panel-336-11-0-0> .panel-widget-style { padding:20px 0px 20px 0px }  } </style>
      <!-- Start of HubSpot Embed Code -->
      <!--script type="text/javascript" id="hs-script-loader" async defer src="js.hs-scripts.com/5653267.js"></script-->
      <!-- End of HubSpot Embed Code -->
   </head>
   <body class="home page-template-default page page-id-336 siteorigin-panels siteorigin-panels-before-js siteorigin-panels-home unknown alt-style-default one-col width-1200 one-col-1200 full-width full-header full-footer">
      <div id="wrapper">
         <div id="inner-wrapper">
            <!--#header-container-->
            <div id="header-container">
               <h3 class="nav-toggle icon"><a href="#navigation">Navigation</a></h3>
               <div id="top_bar">
                  <!-- UberMenu [Configuration:topmenu] [Theme Loc:] [Integration:api] -->
                  <nav id="ubermenu-topmenu-7" class="ubermenu ubermenu-nojs ubermenu-topmenu ubermenu-menu-7 ubermenu-responsive-collapse ubermenu-horizontal ubermenu-transition-shift ubermenu-trigger-hover_intent ubermenu-skin-none  ubermenu-bar-align-right ubermenu-items-align-right ubermenu-bound ubermenu-disable-submenu-scroll ubermenu-sub-indicators ubermenu-retractors-responsive">
                     <ul id="ubermenu-nav-topmenu-7" class="ubermenu-nav">
                        <li id="menu-item-5466" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-5466 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="contact/index.html" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Contact</span></a></li>
                        <li id="menu-item-5467" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-5467 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="support/index.html" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">FAQ</span></a></li>
                        <li id="menu-item-325" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-325 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="sign-up/index.html" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Affiliate Signup</span></a></li>
                        <li id="menu-item-856" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-856 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="sign-up-advertisers-old/index.html" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Advertiser Signup</span></a></li>
                        <li id="menu-item-1085" class="my-account ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-1085 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" target="_blank" href="http://wedebeek.com/v2" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">My Account</span></a></li>
                     </ul>
                  </nav>
                  <!-- End UberMenu -->
               </div>
               <header id="header" >
                  <a href="#" id="home-button-link" style="position:absolute;height:130px;width:130px;top:25px;right:50%;margin-right:-65px;z-index:999999999;"></a>
                  <div class="left"><a href="#" title="wedebeek"><img src="<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/images/mb-logo.png" alt="wedebeek" /></a></div>
                  <div class="center">
                     <!-- UberMenu [Configuration:main_menu] [Theme Loc:] [Integration:api] -->
                     <a class="ubermenu-responsive-toggle ubermenu-responsive-toggle-main_menu ubermenu-skin-none ubermenu-loc- ubermenu-responsive-toggle-content-align-center ubermenu-responsive-toggle-align-full ubermenu-responsive-toggle-icon-only " data-ubermenu-target="ubermenu-main_menu-2"><i class="fa fa-bars"></i></a>
                     <nav id="ubermenu-main_menu-2" class="ubermenu ubermenu-nojs ubermenu-main_menu ubermenu-menu-2 ubermenu-responsive ubermenu-responsive-single-column ubermenu-responsive-single-column-subs ubermenu-responsive-default ubermenu-responsive-collapse ubermenu-horizontal ubermenu-transition-slide ubermenu-trigger-hover_intent ubermenu-skin-none  ubermenu-bar-align-full ubermenu-items-align-center ubermenu-bound ubermenu-retractors-responsive">
                        <ul id="ubermenu-nav-main_menu-2" class="ubermenu-nav">
                           <li id="menu-item-9755" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-9755 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="#pg-336-1" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Products</span></a></li>
                           <li id="menu-item-9568" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-9568 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="#pg-336-11" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">About us</span></a></li>
                           <li id="menu-item-323" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-323 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="#pg-336-3" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Careers</span></a></li>
                           <li id="menu-item-9517" class="logo-class ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-current-menu-item ubermenu-current_page_item ubermenu-item-home ubermenu-item-9517 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="index.html" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">LOGO</span></a></li>
                           <li id="menu-item-4030" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-4030 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="#pg-336-4" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Blog</span></a></li>
                           <li id="menu-item-8222" class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-8222 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="#pg-336-5" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Events</span></a></li>
                           <li id="menu-item-9570" class="ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-9570 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="#mailcampform" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Contact</span></a></li>
                           <li id="menu-item-9821" class="mobile-menu-item ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-9821 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="team/index.html" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Team</span></a></li>
                           <li id="menu-item-9822" class="mobile-menu-item ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-9822 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="hiro/index.html" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Hiro</span></a></li>
                           <li id="menu-item-9823" class="mobile-menu-item ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-9823 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="gallery/index.html" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Gallery</span></a></li>
                           <li id="menu-item-11425" class="mobile-menu-item ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-11425 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="#" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Private Collection</span></a></li>
                           <li id="menu-item-6305" class="mobile-menu-item ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-6305 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="#mailcampform" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">FAQ</span></a></li>
                           <li id="menu-item-9802" class="mobile-menu-item ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-9802 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="http://wedebeek.com/v2" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Affiliate Signup</span></a></li>
                           <li id="menu-item-6306" class="mobile-menu-item ubermenu-item ubermenu-item-type-post_type ubermenu-item-object-page ubermenu-item-6306 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="mailcampform" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">Advertiser Signup</span></a></li>
                           <li id="menu-item-9803" class="mobile-menu-item ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-9803 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-item-layout-default ubermenu-item-layout-text_only" href="http://wedebeek.com/v2" tabindex="0"><span class="ubermenu-target-title ubermenu-target-text">My Account</span></a></li>
                           <li id="menu-item-6312" class="mobile-menu-item mobile-social-menu ubermenu-item ubermenu-item-type-custom ubermenu-item-object-ubermenu-custom ubermenu-item-6312 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" >
                              <div class="ubermenu-content-block ubermenu-custom-content">
                                 <!-- UberMenu [Configuration:icon_menu] [Theme Loc:] [Integration:api] -->
                                 <nav id="ubermenu-icon_menu-25" class="ubermenu ubermenu-nojs ubermenu-icon_menu ubermenu-menu-25 ubermenu-responsive-collapse ubermenu-horizontal ubermenu-transition-shift ubermenu-trigger-hover_intent ubermenu-skin-none  ubermenu-bar-align-full ubermenu-items-align-right ubermenu-bound ubermenu-disable-submenu-scroll ubermenu-sub-indicators ubermenu-retractors-responsive">
                                    <ul id="ubermenu-nav-icon_menu-25" class="ubermenu-nav">
                                       <li id="menu-item-5543" class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-5543 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-target-with-icon ubermenu-item-layout-default ubermenu-item-layout-icon_left ubermenu-item-notext" target="_blank" href="https://www.facebook.com/superbi11" tabindex="0"><i class="ubermenu-icon fa fa-facebook"></i></a></li>
                                       <li id="menu-item-5544" class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-5544 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-target-with-icon ubermenu-item-layout-default ubermenu-item-layout-icon_left ubermenu-item-notext" target="_blank" href="https://twitter.com/wedebeek" tabindex="0"><i class="ubermenu-icon fa fa-twitter"></i></a></li>
                                       <li id="menu-item-5545" class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-5545 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-target-with-icon ubermenu-item-layout-default ubermenu-item-layout-icon_left ubermenu-item-notext" target="_blank" href="https://www.linkedin.com/in/bi-phan-b8629a135" tabindex="0"><i class="ubermenu-icon fa fa-linkedin"></i></a></li>
                                       <li id="menu-item-5546" class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-5546 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-target-with-icon ubermenu-item-layout-default ubermenu-item-layout-icon_left ubermenu-item-notext" target="_blank" href="https://www.instagram.com/wedebeek/" tabindex="0"><i class="ubermenu-icon fa fa-instagram"></i></a></li>
                                    </ul>
                                 </nav>
                                 <!-- End UberMenu -->
                              </div>
                           </li>
                        </ul>
                     </nav>
                     <!-- End UberMenu -->
                  </div>
                  <div class="right">
                     <!-- UberMenu [Configuration:icon_menu] [Theme Loc:] [Integration:api] -->
                     <nav id="ubermenu-icon_menu-25" class="ubermenu ubermenu-nojs ubermenu-icon_menu ubermenu-menu-25 ubermenu-responsive-collapse ubermenu-horizontal ubermenu-transition-shift ubermenu-trigger-hover_intent ubermenu-skin-none  ubermenu-bar-align-full ubermenu-items-align-right ubermenu-bound ubermenu-disable-submenu-scroll ubermenu-sub-indicators ubermenu-retractors-responsive">
                        <ul id="ubermenu-nav-icon_menu-25" class="ubermenu-nav">
                           <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-5543 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-target-with-icon ubermenu-item-layout-default ubermenu-item-layout-icon_left ubermenu-item-notext" target="_blank" href="https://www.facebook.com/superbi11" tabindex="0"><i class="ubermenu-icon fa fa-facebook"></i></a></li>
                           <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-5544 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-target-with-icon ubermenu-item-layout-default ubermenu-item-layout-icon_left ubermenu-item-notext" target="_blank" href="https://twitter.com/wedebeek" tabindex="0"><i class="ubermenu-icon fa fa-twitter"></i></a></li>
                           <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-5545 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-target-with-icon ubermenu-item-layout-default ubermenu-item-layout-icon_left ubermenu-item-notext" target="_blank" href="https://www.linkedin.com/in/bi-phan-b8629a135" tabindex="0"><i class="ubermenu-icon fa fa-linkedin"></i></a></li>
                           <li class="ubermenu-item ubermenu-item-type-custom ubermenu-item-object-custom ubermenu-item-5546 ubermenu-item-level-0 ubermenu-column ubermenu-column-auto" ><a class="ubermenu-target ubermenu-target-with-icon ubermenu-item-layout-default ubermenu-item-layout-icon_left ubermenu-item-notext" target="_blank" href="https://www.instagram.com/wedebeek/" tabindex="0"><i class="ubermenu-icon fa fa-instagram"></i></a></li>
                        </ul>
                     </nav>
                     <!-- End UberMenu -->
                  </div>
               </header>
            </div>
            <!--/#header-container-->
            <!-- #content Starts -->
            <div id="content" class="col-full">
               <div id="main-sidebar-container">
                  <!-- #main Starts -->
                  <section id="main">
                     <article class="post-336 page type-page status-publish hentry">
                        <section class="entry">
                           <div id="pl-336"  class="panel-layout" >
                              <div id="pg-336-0"  class="panel-grid panel-has-style"><div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-336-0" data-stretch-type="full-stretched" >
                                    <div id="pgc-336-0-0"  class="panel-grid-cell" >
                                       <div id="panel-336-0-0-0" class="so-panel widget widget_sow-editor panel-first-child" data-index="0" >
                                          <div class="header-white panel-widget-style panel-widget-style-for-336-0-0-0" >
                                             <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                                <div class="siteorigin-widget-tinymce textwidget">
                                                   <div class="h1-main" >
                                                   wedebeek<br />
                                                   cpa<br /> 
                                                   network
                                                   
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div id="panel-336-0-0-1" class="widget_text so-panel widget widget_custom_html panel-last-child" data-index="1" >
                                       <div class="textwidget custom-html-widget">
                                          <div class="hero-login-mobile">
                                             <div class="hero-login-wrapper">
                                                <a href="http://wedebeek.com/v2" target="_blank" clas="hero-login-button" rel="noopener noreferrer">Login</a>
                                                <a onclick="activateRuBtn()" class="mobile-global-trigger"><img src="<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/images/world.svg" alt="world illustration">		  </a>
                                                <ul class="global-wrapper-mobile">
                                                   <li><a href=#>RU</a></li>
                                                </ul>
                                             </div>
                                          </div>
                                          <div class="top-hero-parent">
                                             <div>
                                                <p style="color: white;font-family: gilroy-light !important;text-transform: uppercase;margin-bottom: 0px;font-size:14px;text-align:center;">Become an</p>
                                                <a class="ps-button-affiliate" href="http://wedebeek.com/v2/sign/up">Affiliate</a>
                                             </div>
                                             <div>
                                                <p style="color: white;font-family: gilroy-light !important;text-transform: uppercase;margin-bottom: 0px;font-size:14px;text-align:center;">Become an</p>
                                                <a class="ps-button-advertiser" href=#mailcampform>Advertiser</a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="pgc-336-0-1"  class="panel-grid-cell" >
                                    <div id="panel-336-0-1-0" class="widget_text so-panel widget widget_custom_html panel-first-child panel-last-child" data-index="2" >
                                       <div class="textwidget custom-html-widget">
                                          <div class="hero-login">
                                             <div class="hero-login-wrapper">
                                                <a href=http://wedebeek.com/v2 target="_blank" clas="hero-login-button" rel="noopener noreferrer">Login</a>
                                                <div class="global-img" href=#>
                                                   <img style="width:30px;" src="<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/images/world.svg" alt="world illustration">
                                                   <ul class="global-wrapper">
                                                      <li><a href=#>RU</a></li>
                                                   </ul>
                                                </div>
                                             </div>
                                          </div>
                                          <img class="hexagon-hero" src="<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/images/hexagon2.svg" alt="hexagon illustration">
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <!--------------ebnd doan loi-->
                           <video 
                              id="so_bgvideo_5f5386d1990da" 
                              class="so_video_bg jquery-background-video" 
                              loop 
                              autoplay 
                              playsinline
                              muted
                              data-bgvideo
                              data-bgvideo-fade-in="500"				data-bgvideo-pause-after="120"				data-bgvideo-show-pause-play=true				data-bgvideo-pause-play-x-pos="right"				data-bgvideo-pause-play-y-pos="top" 
                              >
                              <source src="<?php echo base_url('temp/default/home_site');?>/wedebeek/website/homepage/Comp 1_2.mp4" type="video/mp4">
                              <source src="<?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2017/09/Website_Intro_Video_Berlin-1.webmhd.webm" type="video/webm">
                              <source src="<?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2017/09/Website_Intro_Video_Berlin-1.oggtheora.ogv" type="video/ogg">
                           </video>
                           <script type="text/javascript">
                              (function() {
                              	// Move the video and container into the row as the first child
                              	var video_tag = document.getElementById("so_bgvideo_5f5386d1990da");
                              	var video_overlay = document.getElementById("so_bgvideo_overlay_5f5386d1990da");
                              	var video_row = video_tag.previousSibling;
                              	while(video_row && video_row.nodeType != 1) {
                              		video_row = video_row.previousSibling;
                              	}
                              	var row_inner = video_row.firstChild;
                              	row_inner.insertBefore( video_tag, row_inner.firstChild );
                              	if( video_overlay ) {
                              		row_inner.insertBefore( video_overlay, video_tag.nextSibling);
                              	}
                              	row_inner.className += ' so_video_bg_row jquery-background-video-wrapper';
                              	video_tag.play();
                              }());
                           </script>
                           <div id="pg-336-1"  class="panel-grid panel-has-style" >
                              <div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-336-1" data-stretch-type="full-stretched" >
                                 <div id="pgc-336-1-0"  class="panel-grid-cell" >
                                    <div class="panel-cell-style panel-cell-style-for-336-1-0" >
                                       <div id="panel-336-1-0-0" class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="3" >
                                          <div class="block-padding panel-widget-style panel-widget-style-for-336-1-0-0" >
                                             <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                                <div class="siteorigin-widget-tinymce textwidget">
                                                   <h2>
                                                   BUSINESS PURPOSE <br />
                                                   AND STRATEGY
                                                   </h2>
                                                   <p>
                                                   You use money to advertise fb ads, youtube, google but do not bring worthy results, you want your money to be concretized with finished products from users, you need newer, diverse and potential customers. 
                                                   rather than just coming from basic sources like facebook, youtube, and google. You want to reduce risk in your marketing strategy ...
                                                   </p>
                                                   <p>
                                                   WEDEBEEK will fulfill those requirements. 
                                                   Wedebeek is an online affiliate marketing company in Da Nang that will specify the number of users who come to your product on your behalf without you having to do it directly. 
                                                   </p>
                                                   <p>
                                                   Wedebeek helps you to eliminate risk in advertising and deliver specific advertising results - you only pay when the product you want gets a certain number of customers - specific users, when your product you are sold with a specific order number.
                                                   WEDEBEEK Affiliate Marketing - Your bridge and ladder.
                                                   </p>
                                                   <p><a class="advidi-button" style="color: #231f20;" href="http://wedebeek.com/v2">read more</a></p>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="pgc-336-1-1"  class="panel-grid-cell" >
                                    <div class="panel-cell-style panel-cell-style-for-336-1-1" >
                                       <div id="panel-336-1-1-0" class="widget_text so-panel widget widget_custom_html panel-first-child panel-last-child" data-index="4" >
                                          <div class="textwidget custom-html-widget">
                                             <p class="photo-name"><strong>Bi Phan </strong>Senior Account Manager</p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div id="pg-336-2"  class="panel-grid panel-has-style" >
                              <div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-336-2" id="show-row-sm" data-stretch-type="full" >
                                 <div id="pgc-336-2-0"  class="panel-grid-cell" >
                                    <div id="panel-336-2-0-0" class="widget_text so-panel widget widget_custom_html panel-first-child panel-last-child" data-index="5" >
                                       <div class="textwidget custom-html-widget">
                                          <h2 style="color: white; text-align: center; margin-bottom: 50px;">products<br />& services</h2>
                                          <ul class="accordion-products">
                                             <li style="padding-left: 0;">
                                                <a class="active">
                                                   <h4>affiliate marketing</h4>
                                                </a>
                                                <div style="display: block;">
                                                   <p>Affiliate marketing is a global industry that never stops evolving. We’ve been evolving with it since 2019.</p>
                                                   <p>Whether you’re an affiliate or an advertiser, we help you stay ahead with best-in-class support services.</p>
                                                   <p>On one hand, we add value - you get advanced reports, exclusive offers, powerful creatives, years of data and more.</p>
                                                   <p>At the same time, we remove obstacles - you’ll forget what it was like to stress about cash shortages, fraud, non-responsiveness and other hassles.</p>
                                                   <p>The result is more confidence, more speed and better performance, one campaign after the next.</p>
                                                   <a style="color:white;" class="advidi-button" href="http://wedebeek.com/v2">check all products</a>
                                                </div>
                                             </li>
                                             <li style="padding-left: 0;">
                                                <a>
                                                   <h4>lead generation</h4>
                                                </a>
                                                <div>
                                                   <p>Leads aren’t just contact details on a spreadsheet - they’re people. And we know what it takes to attract people.</p>
                                                   <p>We’ve helped some of the biggest leadgen experts in the world grow audiences in diverse global markets, resulting in a careful balance of quantity and quality.</p>
                                                   <p>This all leads to a simple formula:</p>
                                                   <p>If you’re an advertiser, we’ll send you leads that suit your business model, on demand, with exceptional lifetime value.</p>
                                                   <p>If you’re an affiliate, we’ll find you the offers that deliver the most lucrative return on the leads you generate.</p>
                                                   <a style="color:white;" class="advidi-button" href="http://wedebeek.com/v2">check all products</a>
                                                </div>
                                             </li>
                                             <li style="padding-left: 0;">
                                                <a>
                                                   <h4>business intelligence</h4>
                                                </a>
                                                <div>
                                                   <p>Our dedicated Business Intelligence department is your dedicated Business Intelligence department.</p>
                                                   <p>Get detailed answers at the push of a button with custom-generated reports.</p>
                                                   <p>Spot trends and opportunities with segmented data.</p>
                                                   <p>Make better decisions using trillions of bytes of relevant data.</p>
                                                   <p>When it comes to turning knowledge into power, we’re second to none. And it’s all available to you - our trusted partner.</p>
                                                   <a style="color:white;" class="advidi-button" href="http://wedebeek.com/v2">check all products</a>
                                                </div>
                                             </li>
                                             <li style="padding-left: 0;">
                                                <a>
                                                   <h4>brand safety</h4>
                                                </a>
                                                <div>
                                                   <p>Your brand is your biggest asset. As your partner and advocate, we will treat it with the same respect you do - wielding it as a tool (not a weapon).</p>
                                                   <p>Our Brand Safety guidelines are designed to maintain consistency and trust in a dynamic industry. With our focus on long-term success, your brand earns immediate respect.</p>
                                                   <p>The more we help you grow with stability, the more we can all benefit from your respected name.</p>
                                                   <a style="color:white;" class="advidi-button" href="http://wedebeek.com/v2">check all products</a>
                                                </div>
                                             </li>
                                             <li style="padding-left: 0;">
                                                <a>
                                                   <h4>design service</h4>
                                                </a>
                                                <div>
                                                   <p>Design isn’t a luxury - it’s a necessity.</p>
                                                   <p>You need constant creatives to fuel your campaigns, but you also need them to work. A tall order for any individual or small team… but when you have data from thousands of successful campaigns, you start to see the patterns.</p>
                                                   <p>Our in-house design team equips you with the top-converting creatives in every market we operate in. Not only does this eliminate hassles, it ensures that you’re always getting the best results from your campaigns.</p>
                                                   <p>One less thing to worry about, one more advantage on your side.</p>
                                                   <a style="color:white;" class="advidi-button" href="http://wedebeek.com/v2">check all products</a>
                                                </div>
                                             </li>
                                             <li style="padding-left: 0;">
                                                <a>
                                                   <h4>payment cycle</h4>
                                                </a>
                                                <div>
                                                   <p>You have value. It makes sense that you get paid for it - every time, quickly, no questions asked.</p>
                                                   <p>Our payment cycle is tailored to each partner to ensure optimal risk management and cash flow.</p>
                                                   <p>If you’re an affiliate, we’ll make sure you always have funds for traffic.</p>
                                                   <p>If you’re an advertiser, we’ll make sure you only pay for results that matter to your business.</p>
                                                   <p>To you, it’s that simple.</p>
                                                   <a style="color:white;" class="advidi-button" href="http://wedebeek.com/v2">check all products</a>
                                                </div>
                                             </li>
                                             <li style="padding-left: 0;">
                                                <a>
                                                   <h4>global presence</h4>
                                                </a>
                                                <div>
                                                   <p>A good idea is a good idea. What works in one market will likely work just as well - or better - in another.</p>
                                                   <p>With our global presence, you can stop limiting yourself to what’s available and start thinking about scaling globally.</p>
                                                   <p>Looking for an untapped market? Got a new product that’s destined to break through anywhere? Let Wedebeek be your access point to every important geographical area.</p>
                                                   <a style="color:white;" class="advidi-button" href=products-and-services/index.html>check all products</a>
                                                </div>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div id="pg-336-3"  class="panel-grid panel-has-style" >
                              <div class="product-section siteorigin-panels-stretch panel-row-style panel-row-style-for-336-3" data-stretch-type="full" >
                                 <div id="pgc-336-3-0"  class="panel-grid-cell" >
                                    <div id="panel-336-3-0-0" class="so-panel widget widget_sow-editor panel-first-child" data-index="6" >
                                       <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                          <div class="siteorigin-widget-tinymce textwidget">
                                             <h2 style="color: white;margin-bottom: 50px;">CAREERS <br />AND SERVICES</h2>
                                          </div>
                                       </div>
                                    </div>
                                    <div id="panel-336-3-0-1" class="so-panel widget widget_sow-editor" data-index="7" >
                                       <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                          <div class="siteorigin-widget-tinymce textwidget">
                                             <p style="color:white;">Founded in 2017, Wedebeek has since become one of the industry’s leading performance marketing networks, thanks to our quick adoption of new advertising technologies and persistent hard work. </p>
                                             <p style="color:white;">From a soccer team-sized crew to a company with 100 experts on board - we never cease to evolve, fostering the development of unconventional business approaches, reaching new career heights, and finding new friends to grow and work together with!</p>
                                          
                                          </div>
                                       </div>
                                    </div>
                                    <div id="panel-336-3-0-2" class="widget_text so-panel widget widget_custom_html" data-index="8" >
                                       <div class="textwidget custom-html-widget">
                                          <p style="margin: 50px 0 10px; color:white;text-transform:uppercase;">Learn more about our careers & Services:</p>
                                          <div class="product-button-group">
                                             <a class="ps-button-affiliate" href="http://wedebeek.com/v2/sign/up">i'm an affiliate</a>
                                             <a class="ps-button-advertiser" href=#mailcampform>i'm an advertiser</a>
                                          </div>
                                       </div>
                                    </div>
                                    <div id="panel-336-3-0-3" class="widget_text so-panel widget widget_custom_html panel-last-child" data-index="9" >
                                       <div class="textwidget custom-html-widget"><img id="design-elements" src="<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/images/design-element.svg" alt="design element wedebeek"></div>
                                    </div>
                                 </div>
                                 <div id="pgc-336-3-1"  class="panel-grid-cell" >
                                    <div id="panel-336-3-1-0" class="so-panel widget widget_media_image panel-first-child panel-last-child" data-index="10" >
                                       <div class="panel-widget-style panel-widget-style-for-336-3-1-0" ><img width="500" height="1000" src="<?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2020/01/verticals-vertical-1.png" class="image wp-image-11737  attachment-full size-full" alt="" style="max-width: 100%; height: auto;" srcset="<?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2020/01/verticals-vertical-1.png 500w, <?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2020/01/verticals-vertical-1-150x300.png 150w" sizes="(max-width: 500px) 100vw, 500px" /></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div id="pg-336-4"  class="panel-grid panel-has-style" >
                              <div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-336-4" data-stretch-type="full" >
                                 <div id="pgc-336-4-0"  class="panel-grid-cell" >
                                    <div id="panel-336-4-0-0" class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="11" >
                                       <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                          <div class="siteorigin-widget-tinymce textwidget">
                                             <h2 style="color: white;">The Wedebeek brand</h2>
                                             <p style="color: white;"><strong>In our industry, some people stand out.</strong></p>
                                             <p style="color: white;">You may not recognize them at first glance; they’re defined by their character and their decisions, not their outward appearance. They push new boundaries. They’re not afraid to challenge new markets or take calculated risks. They believe fear is a luxury; they’re too busy taking action.</p>
                                             <p style="color: white;">We believe in these people. We call them performance marketing heroes. We recognize, connect, inspire and support them as they rise - because they bring everyone up with them.</p>
                                             <p style="color: white;margin-bottom:0;">With our partners and our people at our core, we live our values. We find and connect the best people in the industry and create opportunities beyond all expectations. We respect the traditions of our industry, yet bravely challenge it to grow.</p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="pgc-336-4-1"  class="panel-grid-cell" >
                                    <div class="panel-cell-style panel-cell-style-for-336-4-1" >
                                       <div id="panel-336-4-1-0" class="so-panel widget widget_youtube_responsive panel-first-child panel-last-child" data-index="12" >
                                          <h3 class="widget-title"></h3>
                                          <object  class='StefanoAI-youtube-responsive fitvidsignore ' width='160' height='90' style='' type='application/video'><iframe id='StefanoAI-youtube-1' class='StefanoAI-youtube-responsive ' width='160' height='90' src='http://www.youtube.com/embed/T8TksjWdAEw?&amp;playlist=T8TksjWdAEw&amp;autohide=2&amp;color=red&amp;controls=1&amp;disablekb=0&amp;fs=1&amp;iv_load_policy=1&amp;loop=1&amp;modestbranding=1&amp;rel=0&amp;showinfo=0&amp;theme=dark&amp;vq=hd1080' allowfullscreen style='border:none;'></iframe></object>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div id="pg-336-5"  class="panel-grid panel-has-style" >
                              <div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-336-5" data-stretch-type="full" >
                                 <div id="pgc-336-5-0"  class="panel-grid-cell" >
                                    <div id="panel-336-5-0-0" class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="13" >
                                       <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                          <div class="siteorigin-widget-tinymce textwidget">
                                             <div class="affiliate-ps-block-bottom">
                                                <p class="ps-block-title">Affiliates</p>
                                                <p style="color: white;">A world of opportunity. We’re changing the affiliate marketing game, and we’re inviting you to join us.</p>
                                                <p><a class="ps-block-button-bottom" href="http://wedebeek.com/v2/sign/up">SIGN UP!</a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="pgc-336-5-1"  class="panel-grid-cell" >
                                    <div id="panel-336-5-1-0" class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="14" >
                                       <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                          <div class="siteorigin-widget-tinymce textwidget">
                                             <div class="advertiser-ps-block-bottom">
                                                <p class="ps-block-title">Advertisers</p>
                                                <p style="color: white;">An ally you can depend on. We’ll think for you to help your products attract the right audience.</p>
                                                <p><a class="ps-block-button-bottom" href=#mailcampform>SIGN UP!</a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
						   </div>
						   

                           <div id="pg-336-6"  class="panel-grid panel-has-style offer_view" >
                           
                              <div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-336-6" id="first-row" data-stretch-type="full" >
                                
                                <!-- model offer--------------------------------->
                                <?php
                           if(!empty($newoffer)){
                              $mct[0]= $mnct[0] = "";
                              $ct = $this->db->get('country')->result();
                              foreach($ct as $ct){
                                 $mct[$ct->id] = $ct->keycode;
                                 $mnct[$ct->id] = $ct->country;
                              }

                                 $this->load->controller('home/myoffer/',array(0,1));

                           }
                           ?>

                                <!-- end model offer-->
                              </div>
						   </div>
						   


                           <div id="pg-336-7"  class="panel-grid panel-has-style" >
                              <div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-336-7" data-stretch-type="full-stretched" >
                                 <div id="pgc-336-7-0"  class="panel-grid-cell" >
                                    <div class="panel-cell-style panel-cell-style-for-336-7-0" >
                                       <div id="panel-336-7-0-0" class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="19" >
                                          <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                             <div class="siteorigin-widget-tinymce textwidget">
                                                <h3 style="color: white; text-transform: uppercase;">meet Wedebeek at</h3>
                                                <h2 style="color: white; margin-bottom: 10px;"> TES<br />
                                                   2020
                                                </h2>
                                                <h3 style="color: white; text-transform: uppercase;">Lisbon, Cascais</h3>
                                                <p><span style="color: white; text-transform: uppercase;">28th Feb - 1st Mar 2020</span></p>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="pgc-336-7-1"  class="panel-grid-cell" >
                                    <div id="panel-336-7-1-0" class="widget_text so-panel widget widget_custom_html panel-first-child panel-last-child" data-index="20" >
                                       <div class="textwidget custom-html-widget">
                                          <div class="event-slider">
                                             <div class="event-member">
                                                <img src="<?php echo base_url('temp/default/home_site');?>/wedebeek/website/team/paul.jpg" alt="Paul Groen">
                                                <div class="text">
                                                   <h4 style="color:white;margin-top:20px">Paul</h4>
                                                   <p style="color:white;margin-bottom:0"><a style="color:white;font-size:14px" href=mailto:paul.groen@wedebeek.com>paul@wedebeek.com</a></p>
                                                   <p style="color:white;margin-bottom:30px;font-size:14px">Skype: paul.wedebeek</p>
                                                   <a href=mailto:paul.groen@wedebeek.com class="product-button">book a meeting</a>
                                                </div>
                                             </div>
                                             <div class="event-member">
                                                <img src="<?php echo base_url('temp/default/home_site');?>/wedebeek/website/team/victoria.jpg" alt="Victoria Chernyak">
                                                <div class="text">
                                                   <h4 style="color:white;margin-top:20px">Victoria</h4>
                                                   <p style="color:white;margin-bottom:0"><a style="color:white;font-size:14px" href=mailto:victoria.chernyak@wedebeek.com>victoria.chernyak@wedebeek.com</a></p>
                                                   <p style="color:white;margin-bottom:30px;font-size:14px">Skype: victoria.wedebeek</p>
                                                   <a href=mailto:victoria.chernyak@wedebeek.com class="product-button">book a meeting</a>
                                                </div>
                                             </div>
                                             <div class="event-member">
                                                <img src="<?php echo base_url('temp/default/home_site');?>/wedebeek/website/team/maja.jpg" alt="Maja wedebeek">
                                                <div class="text">
                                                   <h4 style="color:white;margin-top:20px">Maja</h4>
                                                   <p style="color:white;margin-bottom:0"><a style="color:white;font-size:14px" href=mailto:maja.mitrovic@wedebeek.com>maja.mitrovic@wedebeek.com</a></p>
                                                   <p style="color:white;margin-bottom:30px;font-size:14px">Skype: maja.wedebeek</p>
                                                   <a href=mailto:maja.mitrovic@wedebeek.com class="product-button">book a meeting</a>
                                                </div>
                                             </div>
                                             <div class="event-member">
                                                <img src="<?php echo base_url('temp/default/home_site');?>/wedebeek/website/team/alyona.jpg" alt="Alyona">
                                                <div class="text">
                                                   <h4 style="color:white;margin-top:20px">Alyona</h4>
                                                   <p style="color:white;margin-bottom:0"><a style="color:white;font-size:14px" href=alyona.nikitenko%40bangmediagroup.html>alyona.nikitenko@wedebeek.com</a></p>
                                                   <p style="color:white;margin-bottom:30px;font-size:14px">Skype: alyona.wedebeek</p>
                                                   <a href=alyona.nikitenko%40bangmediagroup.html class="product-button">book a meeting</a>
                                                </div>
                                             </div>
                                             <div class="event-member">
                                                <img src="<?php echo base_url('temp/default/home_site');?>/wedebeek/website/team/marina.jpg" alt="Marina ">
                                                <div class="text">
                                                   <h4 style="color:white;margin-top:20px">Marina</h4>
                                                   <p style="color:white;margin-bottom:0"><a style="color:white;font-size:14px" href=mailto:marina.baskaric@wedebeek.com>marina.baskaric@wedebeek.com</a></p>
                                                   <p style="color:white;margin-bottom:30px;font-size:14px">Skype: marina.wedebeek</p>
                                                   <a href=mailto:marina.baskaric@wedebeek.com class="product-button">book a meeting</a>
                                                </div>
                                             </div>
                                             <div class="event-member">
                                                <img src="<?php echo base_url('temp/default/home_site');?>/wedebeek/website/team/dennis.jpg" alt="Dennis wedebeek">
                                                <div class="text">
                                                   <h4 style="color:white;margin-top:20px">Dennis</h4>
                                                   <p style="color:white;margin-bottom:0"><a style="color:white;font-size:14px" href=mailto:dennis.douadi@wedebeek.com>dennis.douadi@wedebeek.com</a></p>
                                                   <p style="color:white;margin-bottom:30px;font-size:14px">Skype: dennisdouadi</p>
                                                   <a href=mailto:dennis.douadi@wedebeek.com class="product-button">book a meeting</a>
                                                </div>
                                             </div>
                                             <div class="event-member">
                                                <img src="<?php echo base_url('temp/default/home_site');?>/wedebeek/website/team/jasin.jpg" alt="Jasin wedebeek">
                                                <div class="text">
                                                   <h4 style="color:white;margin-top:20px">Jasin</h4>
                                                   <p style="color:white;margin-bottom:0"><a style="color:white;font-size:14px" href=mailto:jasin.impiglia@wedebeek.com>jasin.impiglia@wedebeek.com</a></p>
                                                   <p style="color:white;margin-bottom:30px;font-size:14px">Skype: jasin.wedebeek</p>
                                                   <a href=mailto:jasin.impiglia@wedebeek.com class="product-button">book a meeting</a>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div id="pg-336-8"  class="panel-grid panel-has-style" >
                              <div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-336-8" data-stretch-type="full" >
                                 <div id="pgc-336-8-0"  class="panel-grid-cell" >
                                    <div id="panel-336-8-0-0" class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="21" >
                                       <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                          <div class="siteorigin-widget-tinymce textwidget">
                                             <h3 style="color:#fff; text-transform:uppercase;">Wedebeek private <br />collection 2019</h3>
                                             <h2 style="color:#fff">Unveiled!</h2>
                                             <p><a class="advidi-button" href=# style="color:white;">Check it out!</a></p>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="pgc-336-8-1"  class="panel-grid-cell" >
                                    <div id="panel-336-8-1-0" class="so-panel widget widget_media_image panel-first-child panel-last-child" data-index="22" ><img width="600" height="600" src="<?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2019/10/web-illu.png" class="image wp-image-11426  attachment-full size-full" alt="" style="max-width: 100%; height: auto;" srcset="<?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2019/10/web-illu.png 600w, <?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2019/10/web-illu-150x150.png 150w, <?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2019/10/web-illu-300x300.png 300w" sizes="(max-width: 600px) 100vw, 600px" /></div>
                                 </div>
                              </div>
                           </div>
                           <div id="pg-336-9"  class="panel-grid panel-has-style" >
                              <div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-336-9" data-stretch-type="full" >
                                 <div id="pgc-336-9-0"  class="panel-grid-cell" >
                                    <div id="panel-336-9-0-0" class="so-panel widget widget_sow-editor panel-first-child panel-last-child" data-index="23" >
                                       <div class="panel-widget-style panel-widget-style-for-336-9-0-0" >
                                          <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                             <div class="siteorigin-widget-tinymce textwidget">
                                                <p style="text-align: center;"><img data-src="<?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2020/01/koa-2019-logo-01-1.png" src="<?php echo base_url('temp/default/home_site');?>/wp-content/uploads/2020/01/koa-2019-logo-01-1.png" data-large_image_width="0" data-large_image_height="0" style="text-align: center;width: 46%;" width="100" height="100"/></p>
                                                <p style="text-align: center;"><a href="http://wedebeek.com/v2" targer="blank" class="primary-button" style="width: 260px;display: inline-block;padding: 15px 20px 15px 20px;margin-top: 15px !important;background: #ee7601;">2020 WINNERS</a></p>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           




                           
                           <div id="pg-336-11"  class="panel-grid panel-has-style" >
                              <div class="siteorigin-panels-stretch panel-row-style panel-row-style-for-336-11" data-stretch-type="full-stretched" >
                                 <div id="pgc-336-11-0"  class="panel-grid-cell" >
                                    <div id="panel-336-11-0-0" class="so-panel widget widget_sow-editor panel-first-child" data-index="27" >
                                       <div class="panel-widget-style panel-widget-style-for-336-11-0-0" >
                                          <div class="so-widget-sow-editor so-widget-sow-editor-base">
                                             <div class="siteorigin-widget-tinymce textwidget">
                                                <h2 style="text-align: center;color:white;">What our partners<br />
                                                   say about us
                                                </h2>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div id="aboutus" class="so-panel widget widget_wp_views panel-last-child" data-index="28" >
                                       <div id="wpv-view-layout-6340" class="js-wpv-view-layout js-wpv-layout-responsive js-wpv-view-layout-6340" data-viewnumber="6340" data-pagination="{&quot;id&quot;:&quot;6340&quot;,&quot;query&quot;:&quot;normal&quot;,&quot;type&quot;:&quot;disabled&quot;,&quot;effect&quot;:&quot;fade&quot;,&quot;duration&quot;:500,&quot;speed&quot;:5,&quot;pause_on_hover&quot;:&quot;disabled&quot;,&quot;stop_rollover&quot;:&quot;false&quot;,&quot;cache_pages&quot;:&quot;enabled&quot;,&quot;preload_images&quot;:&quot;enabled&quot;,&quot;preload_pages&quot;:&quot;enabled&quot;,&quot;preload_reach&quot;:1,&quot;spinner&quot;:&quot;builtin&quot;,&quot;spinner_image&quot;:&quot;<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/wp-views/embedded/res/img/ajax-loader.gif&quot;,&quot;callback_next&quot;:&quot;&quot;,&quot;manage_history&quot;:&quot;enabled&quot;,&quot;has_controls_in_form&quot;:&quot;disabled&quot;,&quot;infinite_tolerance&quot;:&quot;0&quot;,&quot;max_pages&quot;:0,&quot;page&quot;:1,&quot;base_permalink&quot;:&quot;/?wpv_view_count=6340&amp;wpv_paged=WPV_PAGE_NUM&quot;,&quot;loop&quot;:{&quot;type&quot;:&quot;&quot;,&quot;name&quot;:&quot;&quot;,&quot;data&quot;:[],&quot;id&quot;:0}}" data-permalink="/?wpv_view_count=6340">
                                          <div class="testimonials-slider">
                                             <!-- wpv-loop-start -->
                                             <!--div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>Svetlana</h3>
                                                   <h4>Affiliate / Ukraine</h4>
                                                   <span class="testimonial-quote">"They run everything smooth"</span>
                                                   <p>I’ve been working with Wedebeek for quite some time now. The team consists of qualified people who combine professionalism and enthusiasm. They have everything running smooth and are always ready to find the best solution for every request. Moreover, their offer list is one of the hottest on the market. I definitely recommend working with Wedebeek.</p>
                                                </div>
                                             </div>
                                             <div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>Christoph</h3>
                                                   <h4>Advertiser / Germany</h4>
                                                   <span class="testimonial-quote">"Wedebeek is an outstanding player"</span>
                                                   <p>We work with Wedebeek for about two years now. Within this time, Wedebeek became one of our strongest partners, which never fails to impress. Their professionalism combined with dedication makes them an outstanding player in a highly competitive market, and we are looking forward to a bright and long lasting, successful future.</p>
                                                </div>
                                             </div>
                                             <div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>Anastasia</h3>
                                                   <h4>Advertiser / Kiev, Ukraine</h4>
                                                   <span class="testimonial-quote">"They have that rare great understanding"</span>
                                                   <p>Wedebeek is a well organized company with highly professional staff. Their team has that rare great understanding of all customer’s needs and requests that all advertisers are looking for. Always enthusiastic, friendly and creative employees make it a pleasure to build business relationships.</p>
                                                </div>
                                             </div>
                                             <div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>Maurice</h3>
                                                   <h4>Senior Marketing Manager / Hamburg, Germany</h4>
                                                   <span class="testimonial-quote">"They are fast, focused and fucking awesome!"</span>
                                                   <p>We are a global lead generation company and always looking for big volumes and a good data quality. Wedebeek is one of our top  partners, they are providing us exactly with the traffic we are looking for. Quality is always good and they can handle the big numbers. We have offices around the world and had never any issue with reaching our AM. They are fast, focused and fucking awesome!</p>
                                                </div>
                                             </div>                                             
                                             <div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>Tristan</h3>
                                                   <h4>Advertiser / Amsterdam, Netherlands</h4>
                                                   <span class="testimonial-quote">"They will show you that only the sky is the limit"</span>
                                                   <p>It’s a pleasure to work with Wedebeek. Their innovative way of thinking shows you that sky is the limit, and that everything is possible. And so far this has been the case. This approach in combination with their flexible way of working, helped establishing a valuable cooperation. I’m looking forward to see what the future will bring us!</p>
                                                </div>
                                             </div-->



                                             <div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>Chu</h3>
                                                   <h4>Affiliate / vietnam </h4>
                                                   <span class="testimonial-quote">"It's more than just a margin game for them"</span>
                                                   <p>Wedebeek is a fantastic network where I really get this “work hard, play hard" feeling. My AM & BD are very committed and we often hang at their splendid office with a bottle of beer. Working with Wedebeek is more than just a margin game for them. They put effort in you for mutual growth and monetize your traffic strategically.</p>
                                                </div>
                                             </div>
                                             <div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>Drogba</h3>
                                                   <h4>Account Manager / thailand</h4>
                                                   <span class="testimonial-quote">"Strong partnership and good communication"</span>
                                                   <p>I have started working with Wedebeek roughly eight months ago. It has been an engaging ride, along with very reliable and responsive behaviour on their part. Even when times were tough and a lot of attention was required from both ends in order to achieve the results aspired for, we managed to follow through with tenacity and dedication on either side.</p>
                                                </div>
                                             </div>
                                             <div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>CK</h3>
                                                   <h4>Advertiser / Usa</h4>
                                                   <span class="testimonial-quote">"Our most successful partner"</span>
                                                   <p>Wedebeek is one of our most successful partners in this highly competitive industry. We've been working together for a few years already and they have been very professional in every aspect. They offer cutting edge technology with an excellent service. We are proud to be a partner of Wedebeek and we are looking forward to continue this long lasting relationship.</p>
                                                </div>
                                             </div>
                                             <div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>Elier</h3>
                                                   <h4>Advertiser / japan</h4>
                                                   <span class="testimonial-quote">"You just have to step into their office"</span>
                                                   <p>We started working with Wedebeek in 2019. Wedebeek understood our business, and without their high quality traffic we wouldn’t be able to scale like we did.  These guys are the true professionals! Just step into their office and get a taste of the unique, proactive and great atmosphere.</p>
                                                </div>
                                             </div>
                                             <div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>Chris</h3>
                                                   <h4>Affiliate /Korea</h4>
                                                   <span class="testimonial-quote">"You'll not meet nicer group of people in the industry"</span>
                                                   <p>What can I say... Wedebeek were one of the first companies I worked with as an affiliate and the help I received from my account managers was absolutely instrumental in being able to grow my business to what it is today. Such a feel good company to work with and you will not meet a nicer group of people anywhere else in this industry.</p>
                                                </div>
                                             </div>
                                             <div class="testimonial-wrap">
                                                <div class="testimonial">
                                                   <h3>Issac</h3>
                                                   <h4>Affiliate / Singapor</h4>
                                                   <span class="testimonial-quote">"I wholeheartedly recommend them"</span>
                                                   <p>Wedebeek is definitely one of the top affiliate networks I’ve had the pleasure of working with. Great selection of both exclusive and nonexclusive offers, some of the very best affiliate managers in the business, payments are always on time, so long story short: I wholeheartedly recommend them.</p>
                                                </div>
                                             </div>
                                             <!-- wpv-loop-end -->
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
               </div>
               </section><!-- /.entry -->
               </article><!-- /.post -->
               </section><!-- /#main -->
            </div>
            <!-- /#main-sidebar-container -->
         </div>
         <!-- /#content -->
         <div id="mailcampform" style="padding: 50px 0 40px;background: linear-gradient(to right, #37b8eb 0%,#ed0c6e 96%);">
            <h3 style="color:white;text-align:center;margin-bottom: 15px;">STAY UP TO DATE WITH WEDEBEEK</h3>
            <div style="max-width: 900px;padding: 0 20px;margin:auto;">
               		
            </div>
         </div>
         <!--#footer-widgets-container-->
         <div id="footer-widgets-container">
            <section id="footer-widgets" class="col-full col-4">
               <div class="block footer-widget-1">
                  <div id="nav_menu-2" class="widget widget_nav_menu">
                     <h3>Join Wedebeek</h3>
                     <div class="menu-footer-menu-left-container">
                        <ul id="menu-footer-menu-left" class="menu">
                           <li id="menu-item-11902" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11902"><a href="affiliate-signup/index.html">Affiliate Signup</a></li>
                           <li id="menu-item-12084" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12084"><a href="#">Advertisers Signup</a></li>
                           <li id="menu-item-326" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-326"><a href="#">Careers</a></li>
                           <li id="menu-item-9810" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-9810"><a href="http://wedebeek.com/v2">My Account</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="block footer-widget-2">
                  <div id="nav_menu-3" class="widget widget_nav_menu">
                     <h3>About</h3>
                     <div class="menu-footer-menu-center-container">
                        <ul id="menu-footer-menu-center" class="menu">
                           <li id="menu-item-9594" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9594"><a href="#">About Us</a></li>
                           <li id="menu-item-12072" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12072"><a href="#">Products and services affiliates</a></li>
                           <li id="menu-item-12071" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-12071"><a href="#">Products and services advertisers</a></li>
                           <li id="menu-item-331" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-331"><a href="#">Team</a></li>
                           <li id="menu-item-330" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-330"><a href="#">Gallery</a></li>
                           <li id="menu-item-9716" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9716"><a href="#">Hiro</a></li>
                           <li id="menu-item-11424" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11424"><a href="#">Private Collection</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="block footer-widget-3">
                  <div id="nav_menu-4" class="widget widget_nav_menu">
                     <h3>More</h3>
                     <div class="menu-footer-menu-right-container">
                        <ul id="menu-footer-menu-right" class="menu">
                           <li id="menu-item-11707" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-11707"><a href="#">Kings of Wedebeek</a></li>
                           <li id="menu-item-9595" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9595"><a href="#">Blog</a></li>
                           <li id="menu-item-334" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-334"><a href="#">Events</a></li>
                           <li id="menu-item-333" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-333"><a href="#">FAQ</a></li>
                           <li id="menu-item-10938" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10938"><a href="#">Terms and Conditions (Affiliates)</a></li>
                           <li id="menu-item-10939" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10939"><a href="#">Terms and Conditions (Advertisers)</a></li>
                           <li id="menu-item-9387" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9387"><a href="#">Code of Conduct</a></li>
                           <li id="menu-item-9371" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9371"><a href="#">Privacy Policy</a></li>
                           <li id="menu-item-2658" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2658"><a href="#">Contact</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="block footer-widget-4">
                  <div id="text-2" class="widget widget_text">
                     <h3>Say hi</h3>
                     <div class="textwidget">
                        <p>Wedebeek<br />
                        174 Chau Thi Vinh Te<br />
                         My An, Ngu Hanh Son<br />
                         Da Nang 56000
                           
                           
                        </p>
                        <p><a class="facebook-footer" style="color: #666;" href="https://www.facebook.com/superbi11" target="_blank" rel="noopener noreferrer"><i class="fab fa-facebook-f" style="margin-right: 7px;"></i> Facebook</a><br />
                           <a class="instagram-footer" style="color: #666;" href="skype:biphan@wedebeek.com?chat" target="_blank" rel="noopener noreferrer"><i class="fab fa-skype" style="margin-right: 4px;"></i> Skype:</a> live:.cid.dc3f3f4d372582ea(Bi phan|Wedebeek)<br />
                           <a class="twitter-footer" style="color: #666;" href="mailto:biphan@wedebeek.com" target="_blank" rel="noopener noreferrer"><i class="fas fa-at" style="margin-right: 3px;"></i> Email:</a> biphan@wedebeek.com<br />
                           <a class="linkedin-footer" style="color: #666;" href="https://www.linkedin.com/in/bi-phan-b8629a135" target="_blank" rel="noopener noreferrer"><i class="fab fa-linkedin-in" style="margin-right: 4px;"></i> LinkedIn</a><br />
                        </p>
                     </div>
                  </div>
               </div>
               <div class="fix"></div>
            </section>
            <!--/#footer-widgets-->
         </div>
         <!--/#footer_widgets_container_end-->
         <!--#footer_container_start-->
         <div id="footer-container">
            <footer id="footer" class="col-full">
               <div id="copyright" class="col-left">
                  <p><span></span></p>
               </div>
               <div id="credit" class="col-right">
                  <p><span></span></p>
               </div>
            </footer>
         </div>
         <!--/#footer_container_end-->
      </div>
      <!-- /#inner-wrapper -->
      </div><!-- /#wrapper -->
      <div class="fix"></div>
      <!--/.fix-->
      <a id="scroll_top" href="#inner-wrapper"></a>
      <script type="text/javascript">
         const wpvViewHead = document.getElementsByTagName( "head" )[ 0 ];
         const wpvViewExtraCss = document.createElement( "style" );
         wpvViewExtraCss.textContent = `<!--[if IE 7]><style>
         .wpv-pagination { *zoom: 1; }
         </style><![endif]-->
         `
         wpvViewHead.appendChild( wpvViewExtraCss );
      </script>
      <link rel='stylesheet' id='fifu-woo-css-css'  href='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/featured-image-from-url/includes/html/css/woo03ec.css?ver=5.3.4' type='text/css' media='all' />
      <style id='fifu-woo-css-inline-css' type='text/css'>
         img.zoomImg {display:inline !important}
      </style>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/wp-views/public/js/views-frontenddeae.js?ver=3.2.1'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var countVars = {"disqusShortname":"wedebeeknetwork"};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/disqus-comment-system/public/js/comment_countd4e0.js?ver=3.0.17'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var leadin_wordpress = {"userRole":"visitor","pageType":"home","leadinPluginVersion":"7.33.3"};
         /* ]]> */
      </script>
      <!--script async defer id="hs-script-loader" type='text/javascript' src='js.hs-scripts.com/5653267a466.js?integration=WordPress'></script-->
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/video-backgrounds-for-siteorigin-page-builder/assets/jquery.background-videoc64e.js?ver=1.1.1'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/js/strl-js5152.js?ver=1.0'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/themes/canvas-child/js/slick-minaff7.js?ver=1.6.0'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/wp-views/vendor/toolset/toolset-common/res/lib/bootstrap3/js/bootstrap.min7433.js?ver=3.3.7'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var ubermenu_data = {"remove_conflicts":"on","reposition_on_load":"off","intent_delay":"300","intent_interval":"100","intent_threshold":"7","scrollto_offset":"50","scrollto_duration":"1000","responsive_breakpoint":"959","accessible":"on","retractor_display_strategy":"responsive","touch_off_close":"on","collapse_after_scroll":"on","v":"3.2.7","configurations":{"1":"main_menu","2":"icon_menu","3":"topmenu","4":"main"},"ajax_url":"https:\/\/wedebeek.com\/wp-admin\/admin-ajax.php","plugin_url":"https:\/\/wedebeek.com\/wp-content\/plugins\/ubermenu\/"};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/ubermenu/assets/js/ubermenu.min2c3d.js?ver=3.2.7'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/ubermenu/custom/custom2c3d.js?ver=3.2.7'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/wp-embed.min03ec.js?ver=5.3.4'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var fifuImageVars = {"fifu_lazy":"","fifu_woo_lbox_enabled":"1","fifu_woo_zoom":"inline"};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/featured-image-from-url/includes/html/js/image85a3.js?3_1_1&amp;ver=5.3.4'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var panelsStyles = {"fullContainer":"body"};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/siteorigin-panels/js/styling-2110.min6af1.js?ver=2.11.0'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/jquery/ui/core.mine899.js?ver=1.11.4'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/jquery/ui/datepicker.mine899.js?ver=1.11.4'></script>
      <script type='text/javascript'>
         var mejsL10n = {"language":"en","strings":{"mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen-off":"Turn off Fullscreen","mejs.fullscreen-on":"Go Fullscreen","mejs.download-video":"Download Video","mejs.fullscreen":"Fullscreen","mejs.time-jump-forward":["Jump forward 1 second","Jump forward %1 seconds"],"mejs.loop":"Toggle Loop","mejs.play":"Play","mejs.pause":"Pause","mejs.close":"Close","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.time-skip-back":["Skip back 1 second","Skip back %1 seconds"],"mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.mute-toggle":"Mute Toggle","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.ad-skip":"Skip ad","mejs.ad-skip-info":["Skip in 1 second","Skip in %1 seconds"],"mejs.source-chooser":"Source Chooser","mejs.stop":"Stop","mejs.speed-rate":"Speed Rate","mejs.live-broadcast":"Live Broadcast","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};
      </script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/mediaelement/mediaelement-and-player.minc270.js?ver=4.2.13-9993131'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/mediaelement/mediaelement-migrate.min03ec.js?ver=5.3.4'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/mediaelement/wp-mediaelement.min03ec.js?ver=5.3.4'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/underscore.min4511.js?ver=1.8.3'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/wp-util.min03ec.js?ver=5.3.4'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/backbone.min2fca.js?ver=1.4.0'></script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-includes/js/mediaelement/wp-playlist.min03ec.js?ver=5.3.4'></script>
      <script type='text/javascript'>
         /* <![CDATA[ */
         var wpv_pagination_local = {"front_ajaxurl":"https:\/\/wedebeek.com\/wp-admin\/admin-ajax.php","calendar_image":"https:\/\/wedebeek.com\/wp-content\/plugins\/wp-views\/embedded\/res\/img\/calendar.gif","calendar_text":"Select date","datepicker_min_date":null,"datepicker_max_date":null,"datepicker_min_year":"1582","datepicker_max_year":"3000","resize_debounce_tolerance":"100","datepicker_style_url":"https:\/\/wedebeek.com\/wp-content\/plugins\/wp-views\/vendor\/toolset\/toolset-common\/toolset-forms\/css\/wpt-jquery-ui\/jquery-ui-1.11.4.custom.css","wpmlLang":""};
         /* ]]> */
      </script>
      <script type='text/javascript' src='<?php echo base_url('temp/default/home_site');?>/wp-content/plugins/wp-views/embedded/res/js/wpv-pagination-embeddeddeae.js?ver=3.2.1'></script>
      <script type="text/javascript">document.body.className = document.body.className.replace("siteorigin-panels-before-js","");</script>        <script type="text/javascript">
         function AI_responsive_widget() {
         	jQuery('object.StefanoAI-youtube-responsive').each(function () {
         		jQuery(this).parent('.fluid-width-video-wrapper').removeClass('fluid-width-video-wrapper').removeAttr('style').css('width', '100%').css('display', 'block');
         		jQuery(this).children('.fluid-width-video-wrapper').removeClass('fluid-width-video-wrapper').removeAttr('style').css('width', '100%').css('display', 'block');
         		var width = jQuery(this).parent().innerWidth();
         		var maxwidth = jQuery(this).css('max-width').replace(/px/, '');
         		var pl = parseInt(jQuery(this).parent().css('padding-left').replace(/px/, ''));
         		var pr = parseInt(jQuery(this).parent().css('padding-right').replace(/px/, ''));
         		width = width - pl - pr;
         		if (maxwidth < width) {
         			width = maxwidth;
         		}
         		jQuery(this).css('width', width + "px");
         		jQuery(this).css('height', width / (16 / 9) + "px");
         		jQuery(this).find('iframe').css('width', width + "px");
         		jQuery(this).find('iframe').css('height', width / (16 / 9) + "px");
         	});
         }
         if (typeof jQuery !== 'undefined') {
         	jQuery(document).ready(function () {
         		var tag = document.createElement('script');
         		tag.src = "https://www.youtube.com/iframe_api";
         		var firstScriptTag = document.getElementsByTagName('script')[0];
         		firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
         		AI_responsive_widget();
         	});
         	jQuery(window).resize(function () {
         		AI_responsive_widget();
         	});
         }
         	
      </script>
      <div style="padding: 10px 0;font-size: 12px;background-color: #f2f2f2;">
         <div style="max-width: 1200px;margin: auto;padding-left: 30px;">Copyright © 2019-2020 Wedebeek, All Rights Reserved</div>
      </div>
   </body>
</html>