<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Adm_mng extends CI_Controller { 
    private $page_load='';// chi dinh de load view nao. neu rong thi load mac dinh theo ten bang
    private $databk='';//data function run
    //phan trang
    private $base_url_trang = '#';
    private $total_rows = 100;
    private $per_page =50;
    private $uri_phantrang = 4;
    ///
    public $pub_config='';
    function __construct(){
        parent::__construct();
        if(!$this->session->userdata('adlogedin')||!$this->session->userdata('aduserid')){           
            redirect('ad_user');
            $this->inic->sysm();
            exit();
        }else{
            $this->session->set_userdata('upanh',1);
        }
        $this->pub_config= unserialize(file_get_contents('setting_file/publisher.txt'));
    } 
    ///cashout
    function index(){
           $this->users();
    }
    //tu dong dang nhap acc mem
    function viewmember($id=0){
        if($id){
            $this->session->set_userdata('logedin',1);
            $this->session->set_userdata('userid',$id);
            redirect('publishers/account');
        }
    }
    /////////////
    function del_u($id=0){
        
            $this->db->where('id',(int)$id);
            $this->db->select('manager');
            $t= $this->db->get('users')->row();
            if($t->manager==$this->session->userdata('aduserid')){
                $this->db->where('id',(int)$id);
                $this->db->delete('users');
                redirect('manager/users');
            }else{
                echo 'Action not allow!';
                return;
            }
            
    

    }
    function users($offset = 0,$dk='d',$id=0){    
        //config phần trang
        $this->base_url_trang = base_url($this->config->item('manager').'/users/');
        $this->uri_phantrang = 3;
        $this->per_page =20;
        //end configphântrang
        
        //get nội dụng list file
        //phan trang
        $uid = $this->session->userdata('aduserid');
        $w = $this->session->userdata('manager_u_where');       
        $where = "manager = $uid";       
        if(count($w)){           
            $num = $w['status'];
            if(is_numeric($num))
            {               
                $where = $where. " AND `status` = $num";
                }
        
        }

        //get data
        $qr  = "SELECT *
                FROM `cpalead_users`
                WHERE $where 
                ORDER BY `id` DESC 
                LIMIT $offset,$this->per_page
            ";
            $data_user = $this->db->query($qr)->result(); 

            //phân trang
            $qr  = "SELECT COUNT(*) as total
                FROM `cpalead_users`
                WHERE $where 
            ";
            $tt = $this->db->query($qr)->row();        
            $this->total_rows = $tt->total;
            $this->phantrang();
                    
            $content =$this->load->view('content/users_list',array('dulieu'=>$data_user),true);
            $this->load->view('index',array('content'=>$content ));

    }
    //add user
    function addusers(){ 
        $thongbao = '';
        if($_POST){
            $data['manager']=$this->session->userdata('aduserid');    
            $data['activated']=1;            
            $data['status']=1;
            $data['ref'] ="admin"; 
            $data['balance'] = $data['curent'] = $_POST['balance'];
            /////
            //xu ly first name
            $chuoimailing= 'a:15:{s:9:"firstname";s:3:"N/A";s:8:"lastname";s:3:"N/A";s:7:"company";s:3:"N/A";s:2:"ad";s:3:"N/A";s:4:"city";s:3:"N/A";s:5:"state";s:3:"N/A";s:3:"zip";s:3:"N/A";s:7:"country";s:13:"United States";s:3:"ssn";s:0:"";s:14:"payment_method";s:6:"Paypal";s:12:"payment_info";s:3:"N/A";s:10:"incentives";s:2:"NO";s:8:"Birthday";s:3:"N/A";s:11:"trafficdesc";s:3:"N/A";s:13:"affiliate_man";s:3:"N/A";}';
            $mailing = unserialize($chuoimailing);
            if($_POST['firstname'])$mailing['firstname'] = $_POST['firstname'];else $mailing['firstname'] ='N/A';
            if($_POST['lastname'])$mailing['lastname'] = $_POST['lastname'];else $mailing['lastname'] ='N/A';
            $data['mailling'] = serialize($mailing);                        
            //end xu ly name
            if($_POST['password'] &&  $_POST['email']){
                $data['password']=sha1(md5($_POST['password']));
                $data['email'] = $_POST['email'];
                //check xem email da ton tai chua
                if($this->Home_model->get_one('users',array('email'=>$_POST['email']))){
                    $thongbao = '<div class="alert alert-warning" role="alert">Emails exits!!!</div>';
                }else{
                    if($this->db->insert('users',$data)){                       
                       $thongbao = '<div class="alert alert-success" role="alert">Done!!</div>';
                    }else{                        
                        $thongbao = '<div class="alert alert-danger" role="alert">Error!!</div>';
                    }
                }
            }else{                
                $thongbao = '<div class="alert alert-warning" role="alert">Email or password not required!!</div>';
            }
            $this->session->set_flashdata('thongbao_adduser',$thongbao);
            
            redirect($_SERVER["HTTP_REFERER"]);
            
            
        }else{
            $this->load->view(
                'admin/index',
                array(
                    'content'=>$this->load->view('content/addusers',array('thongbao'=>$thongbao),true)
                    )
                );

        }
       
         
    }
    function showev($table,$dieukhien='',$number=''){
        //add user
        if($table=='users'){
            $this->load->view('content/users_edit');
        }
        ///hien credit cua user
        if($table=='tracklink'){
            $userid = $dieukhien;//user id
            $this->session->set_userdata('userid',$userid);
            $this->session->set_userdata('group_oid',1);
            redirect(base_url('mng_report'));
        }
        
    }



    ///cashout
    function tracklink($dk=0,$id=0){
        $this->base_url_trang = base_url($this->config->item('manager').'/tracklink/list/');
        $content= $this->run('tracklink','list',$id);
        $this->load->view('manager/index',array('content'=>$content));
    }
    function request($dk=0,$id=0){
        $this->base_url_trang = base_url($this->config->item('manager').'/request/list/');;
        $content= $this->run('request','list',$id);
        $this->load->view('manager/index',array('content'=>$content));
    }
    function payment($dk=0,$id=0){
        $this->base_url_trang = base_url($this->config->item('manager').'/payment/list/');;
        $content= $this->run('payment','list',$id);
        $this->load->view('manager/index',array('content'=>$content));
    }
    function info(){
        $thongbao = '';
        $userid =$this->session->userdata('aduserid');        
        if($_POST){
            $images = $this->input->post('images',true);
            $name = $this->input->post('name',true);
            
            $crpass = $this->input->post('crpass',true);
            $npass = $this->input->post('password',true);
            $cpass = $this->input->post('confirmpass',true);
            if($crpass||$npass||$cpass){                
                if(empty($crpass)){
                    $thongbao = "Current Password field is required.";
                }else{
                    if($this->Home_model->get_one('manager',array('id'=>$userid,'password'=>sha1(md5($crpass))))){
                        
                        if($npass != $cpass){
                            $thongbao = "Your confirmation code does not match";
                        }else{
                            $this->db->where('id',$userid);
                            $this->db->update('manager',array('images'=>$images,'name'=>$name,'password'=>sha1(md5($cpass)) ));
                            $thongbao = "You have successfully changed your password!";
                        }
                        
                    }else{
                        $thongbao = "Current password does not match!";
                    }
                }
                
            }else{
                $this->db->where('id',$userid);
                $this->db->update('manager',array('images'=>$images,'name'=>$name));
                $thongbao = "Updated!";
            }
        }
        $dt = $this->Home_model->get_one('manager',array('id'=>$userid));
        $content= $this->load->view('manager/content/info',array('dt'=>$dt,'thongbao'=>$thongbao),true);
        $this->load->view('manager/index',array('content'=>$content));
    }
    
    function disoffer($dk=0,$id=0)
    {
       if($dk=='delete'){
            $this->db->where('id',(int)$id);
            $this->db->select('manager');
            $t= $this->db->get('disoffer')->row();
            if($t->manager==$this->session->userdata('aduserid')){
                $this->db->delete('disoffer');
                redirect('manager/disoffer/list');
            }else{
                echo 'Action not allow!';
                return;
            }
            
            
       }
        $content = $this->run('disoffer','list',$id);
        $this->load->view('manager/index',array('content'=>$content ));
    
    }
   
    
    function ajax($rt=''){
        if($rt=='show_num'){
            $limit = $this->session->userdata('limit');
            $limit['0'] = $this->input->post('data');
            $this->session->set_userdata('limit',$limit);
        }
        if($rt=='filter_users'){
            $data = $this->input->post('data');
            $where = $this->session->userdata('manager_u_where');
            if($data=='all'){
                unset($where['status']);
            }else{
                $where['status'] = $data;
                
            } 
            $this->session->set_userdata('manager_u_where',$where);
           
        }
        if($rt=='requestoff'){
            if($_POST){
                $id=$this->input->post('id',true);
                $val=$this->input->post('val',true);
                $this->db->where('id',$id);
                $this->db->update('request',array('status'=>$val));
                echo $id;
               }
        }
        
        if($rt=='ban_user'){
             if($_POST){
                    $id=(int)$this->input->post('id',true);
                    $val=(int)$this->input->post('val',true);
                    //tao password
                    //$this->load->helper('string');
                    //$pass= random_string('alnum', 8);
                    $this->db->where('id',$id);
                    $this->db->update('users',array('status'=>$val));
                    $acc = $this->Home_model->get_one('users',array('id'=>$id));
                    $toemail = trim($acc->email);
                    $tieude='';
                    $noidung='';
                    $mailign = unserialize($acc->mailling);
                    $firstname=$mailign['firstname'];
                    $lastname = $mailign['lastname'];
                    if($val==0){}//pending
                    if($val==1){//aapprove
                        $tieude='Your Application Has Been Approved';
                        $noidung="
                            Dear Partner,<p>
                            We have reviewed your application and you have been approved as a Wedebeek affiliate. You may now log into obtain creatives to promote all of our offers. Your login information is as follows:
                                <br/>
                            Wedebeek Log in Link:<br/>
                            Log in link: https://wedebeek.com/v2/sign/in
                            <br/>
                            
                            Username:<br/>
                            $acc->email / Your password seting.<br/>

                            Postback Information:<br/>
                            Clickid: {sub1}<br/>
                            Pubid: {sub2}<br/>
                            Conversion payout: {sum}<br/>
                            You can check more marco in postback seting account.<br/>
                            Any more help kindly contact us via skype id: live:.cid.dc3f3f4d372582ea or tegegram id: @BIPHAN_WEDEBEEK.<br/>

                            You will be assigned a account manager in the next 48 hours, in which time they will be in contact to introduce themselves.<br/>

                            Many Thanks                 <br/>       
                            
                        ";
                        if(!$this->guimail($toemail,$tieude,$noidung)){
                            //gui mail k thanh cong co the luwu lai mail roi de cronjob gui
                            $this->guimail($toemail,$tieude,$noidung);
                        }
                    }
                    if($val==2){
                        $tieude='Welcome to '.$this->pub_config['sitename'].'- Account paused!';
                        $noidung= 'Dear partner!<p>
                        We\'re sorry to report that your account has been paused for quality coming from traffic source.<br/> 
                        Contact skype if you have any question: live:.cid.dc3f3f4d372582ea  ( Bi Phan|Wedebeek ).';
                        if(!$this->guimail($toemail,$tieude,$noidung)){
                            //gui mail k thanh cong co the luwu lai mail roi de cronjob gui
                            $this->guimail($toemail,$tieude,$noidung);
                        }
                    }//pause
                    if($val==3){
                        $tieude='Welcome to '.$this->pub_config['sitename'].'- Account banned!';
                        $noidung= 'Dear partner!<p>
                        We\'re sorry to report that your account has been banned for quality coming from traffic source.<br/> 
                        Contact skype if you have any question: live:.cid.dc3f3f4d372582ea  ( Bi Phan|Wedebeek ).';
                        if(!$this->guimail($toemail,$tieude,$noidung)){
                            //gui mail k thanh cong co the luwu lai mail roi de cronjob gui
                            $this->guimail($toemail,$tieude,$noidung);
                        }

                    }//banned  
                    if($val==4){
                        $tieude='Account is not approved';
                        $noidung= 'Dear Partner,<p>
                        Thank you for showing your interest in cooperation with Wedebeek, we really appreciate it.<br/> 
                        Sorry, at the moment we can not accept you as an affiliate, but will place your request to our waiting list and will contact in case there is a possibility.
                        ';
                        if(!$this->guimail($toemail,$tieude,$noidung)){
                            //gui mail k thanh cong co the luwu lai mail roi de cronjob gui
                            $this->guimail($toemail,$tieude,$noidung);
                        }

                    }//rẹject                
                    
                    echo $val;
               }
        }
    }
  
 
    
    function phantrang(){
       $this->load->library('pagination');// da load ben tren
        if($this->base_url_trang == '#'){
          $config['base_url'] = base_url().$this->config->item('manager').'/'.$this->uri->segment(2).'/'.$this->uri->segment(3).'/'.$this->uri->segment(4).'/';
          
        }else{
            $config['base_url'] =$this->base_url_trang;
        }
        $config['total_rows'] = $this->total_rows;
        $config['per_page'] = $this->per_page;
        $config['uri_segment'] = $this->uri_phantrang;
        $config['num_links'] = 9;
        $config['first_link'] = '<<';
        $config['first_tag_open'] = '<li class="firt_page">';//div cho chu <<
        $config['first_tag_close'] = '</li>';//div cho chu <<
        $config['last_link'] = '>>';
        $config['last_tag_open'] = '<li class="last_page">';
        $config['last_tag_close'] = '</li>';
        //-------next-
        $config['next_link'] = 'next &gt;';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        //------------preview
        $config['prev_link'] = '&lt; prev';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
       // ------------------cu?npage
        $config['cur_tag_open'] = '<li class="active"><a href=#>';
        $config['cur_tag_close'] = '</a></li>';
        //--so 
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        //-----
        $this->pagination->initialize($config);
    
    }
    
}
/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */