<div class="bg-dark text-secondary px-4 py-5 text-center nd1 d-flex align-items-center justify-content-center">
         <img src="<?php echo base_url('upload/images/bg1.jpg');?>" class="nd1_bg"/>
         <div class="py-5 align-items-center nd1_ct">
            <h1 class="display-5 fw-bold text-white">WEDEBEEK CPA NETWORK</h1>
            <div class="col-lg-6 mx-auto">
               <p class="fs-5 mb-4"></p>
               <h2 class="text-white">
                  We provide opportunities to develop
                  long-term partnerships, monetize,
                  and manage your funds
               </h2>
               <p class="fs-5 mb-4"></p>
               <div class="d-grid gap-2 d-sm-flex justify-content-sm-center my-5 bctc">                   
                  <button type="button" class="btn btn-outline-primary btn-lg px-4 me-sm-3 btnaff">AFFILIATE</button>
                  <button type="button" class="btn btn-outline-primary btn-lg px-4  btnadv">ADVERTISER</button>
               </div>
            </div>
         </div>
      </div>