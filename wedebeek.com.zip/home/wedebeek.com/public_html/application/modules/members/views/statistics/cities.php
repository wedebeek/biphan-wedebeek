<div class="_2JyLbpIPgPwI6RhYP28lbl">
   <div class="_12e1_3IHEVbMTMaTUzZ7r9">
      <table role="table">
         <thead>
            <tr role="row">
               <th colspan="1" role="columnheader">&nbsp;<span></span></th>
               <th colspan="2" role="columnheader">Traffic<span></span></th>
               <th colspan="1" role="columnheader">&nbsp;<span></span></th>
               <th colspan="1" role="columnheader">&nbsp;<span></span></th>
               <th colspan="1" role="columnheader">&nbsp;<span></span></th>
            </tr>
            <tr role="row">
               <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">City<span></span></th>
               <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Hosts<span></span></th>
               <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Hits<span></span></th>
               <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Impressions<span></span></th>
               <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Conversions<span></span></th>
               <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Finances<span></span></th>
            </tr>
         </thead>
         <tbody role="rowgroup">
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Bronx</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Santa Clara</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">San Jose</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Seattle</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>3</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Brooklyn</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Pensacola</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Abilene</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Panama City</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Bakersfield</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Kitchener</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell">
                  <div class="vfMk5_UxQXI9UPIwF1yqG"><a class="_3HJFBHwnlFb4c_d31FZhBy" href="/v2/statistics/conversions?date_from=2021-08-01&amp;date_to=2021-09-02&amp;timezone=UTC&amp;currency=USD&amp;page=1&amp;conversionStatus=1%2C%205">1</a></div>
               </td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$23.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Brownwood</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Norristown</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Berlin</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Gloucester City</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Montreal</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Toronto</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Vancouver</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>4</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Scarborough</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Edmonton</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Diamond Bar</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Spring</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Maricopa</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Englewood</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Mesquite</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Mississauga</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>3</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Richmond Hill</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Charlottetown</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>4</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Wauconda</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Mays Landing</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/fr.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Beauvais</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/fr.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Compiegne</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>3</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>3</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Surrey</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Kamloops</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Mont-Joli</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Campbell River</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>5</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell">
                  <div class="vfMk5_UxQXI9UPIwF1yqG"><a class="_3HJFBHwnlFb4c_d31FZhBy" href="/v2/statistics/conversions?date_from=2021-08-01&amp;date_to=2021-09-02&amp;timezone=UTC&amp;currency=USD&amp;page=1&amp;conversionStatus=1%2C%205">1</a></div>
               </td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$23.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Avondale</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/fr.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Lyon</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/us.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Lula</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>2</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Lac La Biche</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>3</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/fr.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Levallois-Perret</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/ca.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Mont-Saint-Hilaire</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/fr.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Avranches</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/fr.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Cergy</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
            <tr role="row" class="">
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL"><img styleprops="[object Object]" src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/fr.svg" style="display: inline-block; width: 1em; height: 1em; vertical-align: middle;"><span class="_1WOmcSS9N_e3KUkqfV0NI">Bettviller</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>1</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$0.00</span></span></td>
            </tr>
         </tbody>
         <tfoot>
            <tr>
               <td colspan="1">Total</td>
               <td colspan="1"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>55</span></span></td>
               <td colspan="1"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>68</span></span></td>
               <td colspan="1"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>0</span></span></td>
               <td colspan="1">
                  <div class="vfMk5_UxQXI9UPIwF1yqG"><a class="_3HJFBHwnlFb4c_d31FZhBy _2WYuGVXe0FBr9Ni6eMd-pM" href="/v2/statistics/conversions?date_from=2021-08-01&amp;date_to=2021-09-02&amp;timezone=UTC&amp;currency=USD&amp;page=1&amp;conversionStatus=1%2C%205">2</a></div>
               </td>
               <td colspan="1"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$46.00</span></span></td>
            </tr>
         </tfoot>
      </table>
   </div>
</div>