// When the user scrolls down 80px from the top of the document, resize the navbar's padding and the logo's font size
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
    document.getElementById("navbar").style.padding = "1px 0px";
    document.getElementById("logo").style.width = "148px";
    document.getElementById("logo").style.height = "40px";
    document.getElementById('text-brand-lg').style.display = "none";
    
  } else {
    document.getElementById("navbar").style.padding = "10px 0px";
    document.getElementById("logo").style.width = "200px";
    document.getElementById("logo").style.height = "54px";
    document.getElementById('text-brand-lg').style.display = "block";
  }
}

//carousel-->
$(document).ready(function(){
  $(".owl-carousel").each(function(){
    $(this).owlCarousel({
      loop:true,
      margin:10,
      nav:true,       
      navText:["<div class='nav-btn prev-slide text-primary'><i class='bi bi-caret-left-fill'></i></div>","<div class='nav-btn next-slide text-primary'><i class='bi bi-caret-right-fill'></i></div>"],    
      responsive:{
          0:{
              items:1
          },
          600:{
              items:3
          },
          1000:{
              items:7
          }
        }
    })

  });
  
 

});
//end carousel-->
