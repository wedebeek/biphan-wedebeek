
<div class="row">
    <div class="box col-md-12">
        <div class="box-header">
            <h2><i class="glyphicon glyphicon-globe"></i><span class="break"></span>Chọn Api </h2>
            <div class="box-icon">
                <a class="btn-add" href="#"><i class="glyphicon glyphicon-list-alt"></i></a>
                <a class="btn-setting" href="#"><i class="glyphicon glyphicon-wrench"></i></a>
                <a class="btn-minimize" href="#"><i class="glyphicon glyphicon-chevron-up"></i></a>
                <a class="btn-close" href="#"><i class="glyphicon glyphicon-remove"></i></a>
            </div>
        </div>
        <div class="box-content">
        <!--- noi dung--->
        <form style="color: cecece;" method="POST" action="">
      
          <div class="row">
              <div class="col-md-12">   
                       
                <div class="form-group alert alert-info">
                    <label>Title</label>
                    <select class="form-control" name="api">
                        <option value="1">Mobvortex</option>
                        <option value="2">leanmobi</option>
                    </select>
                </div> 

                <div class="alert alert-success posbacklink" role="alert">Chọn 1 net muốn lấy offer để add</div>
                <button type="submit" class="btn btn-default">Submit</button>
              </div>
          
          
          </div>
        
        </form>
        
           
      
      <!--noi dung --->
        </div>
    </div>
    <!--/span-->
</div>

