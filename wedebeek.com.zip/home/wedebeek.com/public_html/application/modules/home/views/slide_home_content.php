<div class="bg-dark text-secondary px-4 py-5 nd1 d-flex">
            <img src="<?php echo base_url('upload/images/bg1.jpg');?>" class="nd1_bg"/>
            <div class="py-5 nd1_ct col-md-6 my-2">
              <h1 class="display-5 fw-bold text-white">WEDEBEEK CPA NETWORK</h1>
              <div class="col-lg-6">
                <p class="fs-5 mb-4"></p>
                    <h2 class="text-white">
                    We provide opportunities to develop
                        long-term partnerships, monetize,
                        and manage your funds
                    </h2>
                <p class="fs-5 mb-4"></p>
                <div class="d-grid gap-2 d-sm-flex justify-content-sm-center my-5 bctc">                   
                  <button type="button" class="btn btn-outline-primary btn-lg px-4 me-sm-3 btnaff">AFFILIATE</button>
                  <button type="button" class="btn btn-outline-primary btn-lg px-4  btnadv">ADVERTISER</button>
                </div>
              </div>
            </div>
            <div class="col-md-6 text-white ct_content">
                    <?php if(!empty($ct)) echo $ct;?>
            </div>
        </div> 

        <style>
            .ct_content{
              border:1px solid #484242;      
              max-height:600px;
              padding: 10px;
              overflow-y: auto;
            }
        </style>