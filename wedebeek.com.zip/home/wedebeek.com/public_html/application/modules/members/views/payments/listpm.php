<div class="row  mt-5">
   <div class="sc-dlyikq hrvHfq">
      <span class="_1ykwro3W9x7ktXduniR6Cp css-1didjui _2zZKiYIMOuyWJddFzI_uHV">Payments</span>
      <!--div class="sc-hORach fbiYMC">
         <input name="white" type="text" placeholder="Search" class="sc-bMVAic cRFcPy" value=""><span class="sc-bAeIUo eWBLfl">/</span>
         <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="sc-GMQeP kavdHi">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
         </svg>
      </div-->
      <div class="card">
        <div class="card-header">
            <b>Current Payout Amount</b>
        </div>
        <div class="card-body">
            <p class="card-text">You currently have <b>$<?php 
            echo floatval($this->member->available);
            if(floatval($this->pub_config['minpay'])>floatval($this->member->available)){
                $dis=' disabled ';
            }else{
                $dis='';
            }

            ?></b> ready to be paid out. A minimum balance of <b>$<?php echo floatval($this->pub_config['minpay']);?></b> is required to request a payout.</p>
                     
            <form class="row g-3" method="POST" action="<?php echo base_url('v2/request_payouts');?>">                
                <div class="col-auto">
                    <label for="Amount" class="visually-hidden">Amount</label>
                    <input type="text" name="amount" class="form-control form-control-sm" id="" placeholder="Amount">
                </div>
                <div class="col-auto">
                    <label for="Amount" class="visually-hidden">Id paypal</label>
                    <input type="text" name="notes" class="form-control form-control-sm" id="" placeholder="Id paypal">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary mb-3 btn-sm" <?php echo $dis?> >Request Payment</button>
                </div>
            </form>
        </div>
     </div>
     <div class="card mt-2">
        <div class="card-header">
            <b>Payout History</b>
        </div>
        <div class="card-body">

        <div class="sc-eitiEO uHLlo">
          <?php
                if($payment){
                    foreach($payment as $payment){
                        echo '
                        <a class="sc-gGCbJM bfwcis" href="#">
                            <span class="sc-lcpuFF sc-bqjOQT fYJXyK">'.$payment->date.'</span>
                            <span class="sc-lcpuFF sc-jkCMRl iYdzkK">'.$payment->note.'</span>
                            <span class="sc-lcpuFF sc-crNyjn hERdbK">'.$payment->amount.'<span>USD</span></span>
                            <span class="sc-lcpuFF sc-cpHetk fTkPgh">'.$this->member_info['payment_paypal_email'].'</span>
                            <div type="2" class="sc-nrwXf dhYqaO '.$payment->status.'">'.$payment->status.'</div>
                        </a>
                        ';
                    }
                }
          ?>         
         
      </div>
            
        </div>
     </div>
      
   </div>
</div>
<style>
.Reverse{
    background-color:#c5577d !important; 
}
.Pending{
    background-color:#ad7e30 !important; 
}


   /*! CSS Used from: Embedded */
   *{box-sizing:border-box;}
   div,span,a{margin:0px;padding:0px;border:0px;font-size:100%;vertical-align:baseline;}
   .fbiYMC{display:flex;-webkit-box-align:center;align-items:center;width:230px;max-width:450px;position:relative;transition:width 0.1s ease 0s;}
   @media (max-width: 425px){
   .fbiYMC{width:100%;}
   }
   .cRFcPy{outline:0px;border:0px;height:33px;font-size:0.9em;padding:0px 35px 0px 10px;background-color:rgb(236, 236, 238);display:flex;-webkit-box-align:center;align-items:center;width:100%;border-radius:2px;color:rgb(62, 62, 73);}
   .cRFcPy::-webkit-input-placeholder{color:rgb(153, 153, 153);}
   .cRFcPy:focus{padding:0px 60px 0px 10px;}
   .cRFcPy:focus::-webkit-input-placeholder{color:transparent;}
   .eWBLfl{color:rgb(166, 166, 166);position:absolute;right:10px;width:20px;height:20px;display:flex;-webkit-box-align:center;align-items:center;-webkit-box-pack:center;justify-content:center;border:1px solid rgb(187, 187, 187);border-radius:2px;}
   @media (max-width: 425px){
   .eWBLfl{display:none;}
   }
   .kavdHi{position:absolute;right:8px;top:8px;color:rgb(62, 62, 73);display:none;}
   @media (max-width: 425px){
   .kavdHi{display:block;}
   }
   .bfwcis{display:flex;-webkit-box-pack:justify;justify-content:space-between;-webkit-box-align:center;align-items:center;margin-bottom:7px;padding:12px 15px;border-radius:3px;background-color:rgb(255, 255, 255);color:rgb(0, 0, 0);box-shadow:rgba(0, 0, 0, 0.17) 0px 2px 7px 0px;font-size:13px;text-decoration:none;transition:all 0.2s ease 0s;}
   .bfwcis:hover{transform:scale(0.99);}
   @media (max-width: 768px){
   .bfwcis{flex-direction:column;align-items:flex-start;}
   }
   .fYJXyK{width:25%;padding-right:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
   @media (max-width: 768px){
   .fYJXyK{width:100%;margin-bottom:10px;padding-right:0px;}
   }
   .iYdzkK{width:20%;}
   @media (max-width: 768px){
   .iYdzkK{width:100%;margin-bottom:10px;padding-right:0px;}
   }
   .hERdbK{width:15%;color:rgb(131, 131, 131);}
   @media (max-width: 768px){
   .hERdbK{width:100%;margin-bottom:10px;padding-right:0px;}
   }
   .hERdbK > span{padding-left:3px;}
   .fTkPgh{width:25%;padding-right:10px;}
   @media (max-width: 768px){
   .fTkPgh{width:100%;margin-bottom:10px;padding-right:0px;}
   }
   .dhYqaO{display:flex;-webkit-box-pack:center;justify-content:center;width:15%;padding:2px 7px;border-radius:3px;background-color:rgb(73, 142, 68);color:rgb(255, 255, 255);text-transform:uppercase;text-align:center;font-size:12px;}
   @media (max-width: 768px){
   .dhYqaO{width:auto;margin-bottom:0px;}
   }
   .uHLlo{margin-top:20px;}
   .hrvHfq{flex:1 1 0%;}
   /*! CSS Used from: Embedded */
   ._1ykwro3W9x7ktXduniR6Cp{background-color:inherit;display:inline-block;}
   ._2zZKiYIMOuyWJddFzI_uHV{font-size:1.6em;padding:5px 0 15px;}
   /*! CSS Used from: Embedded */
   .css-1didjui{text-transform:capitalize;font-size:18px;color:rgb(102, 102, 102);}
</style>