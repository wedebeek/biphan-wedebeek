<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller { 
    private $per_page = 50;
    function __construct(){
        parent::__construct();   
        $this->pub_config= unserialize(file_get_contents('setting_file/publisher.txt'));
    }
	public function index(){	
       
                
        $data['newoffer']= $this->Home_model->get_data('offer',array('show'=>1),array(9),array('id','DESC'));    
        $data['offer'] = $this->Home_model->get_data('offer',array('show'=>1),array(10));	   
	   $this->load->view('home',$data);       
       
    } 
  
    
    function myoffer($offset=0,$v=0){         
        //////////xu ly get offer va bo loc
        $ocat = (int)$this->input->get_post('cat');
        $ocountry = (int)$this->input->get_post('country');
        $ooffer_type = (int)$this->input->get_post('offer_type');
        if($ocat!=0){
            $this->session->set_userdata('likecat',$ocat);
        }else{
            $this->session->unset_userdata('likecat');
        }
        
        if($ocountry!=0){
            $this->session->set_userdata('likecountry',$ocountry);
        }else{
            $this->session->unset_userdata('likecountry');
        }
        if($ooffer_type!=0){
            $this->session->set_userdata('offertype',$ooffer_type);
        }else{
            $this->session->unset_userdata('offertype');
        }
              
        
       
       
       if(!is_numeric($offset)){$offset=0;}
      
       //get offer approved
       $this->db->select('id');
       $approved = $this->Home_model->get_data('request',array('userid'=>$this->session->userdata('userid')));
       $m = array();
       if($approved){
           foreach($approved as $approved){
               $m[] = $approved->id;
           }
       }
       
       if($this->session->userdata('likecat')){
           $this->db->where('offercat',$this->session->userdata('likecat'));
       }
       
       if($this->session->userdata('offertype')){
           $this->db->where('type',$this->session->userdata('offertype'));
       }
       if($this->session->userdata('likecountry')){
           $this->db->like('country','o'.$this->session->userdata('likecountry').'o');
       }
       
      if($this->session->userdata('camp_approved')){           
           $subquery='select id from cpalead_offer where id in (select offerid from cpalead_request where userid ='.$this->session->userdata('userid').') or request = 0';
           $id = $this->db->query($subquery)->result();
           if($id){
               foreach ($id as $id){
                   $mid[] = $id->id;
               }
               $this->db->where_in('id',$mid);
           }         
       }
       
       $this->db->order_by('id','DESC');
       $this->db->where('show',1);        
       //$this->db->where('request',0);        
       $this->db->limit($this->per_page,$offset);               
       $data['offer'] = $this->db->get('offer')->result();
       
       if($this->session->userdata('likecat')){
           $this->db->like('offercat',$this->session->userdata('likecat'));
       }
       
       if($this->session->userdata('offertype')){
           $this->db->where('type',$this->session->userdata('offertype'));
       }
       
       if($this->session->userdata('camp_approved')){           
           $subquery='select id from cpalead_offer where id in (select offerid from cpalead_request where userid ='.$this->session->userdata('userid').') or request = 0';
           $id = $this->db->query($subquery)->result();
           if($id){
               foreach ($id as $id){
                   $mid[] = $id->id;
               }
               $this->db->where_in('id',$mid);
           }         
       }
       $this->total_rows = $this->Home_model->get_number('offer',array('show'=>1));
       $this->phantrang();
       
       
      
       ///end xu ly get offer va bo loc        
       $data['offercat'] = $ooffer_type=$ocountry=$data['motype']=$data['mocat']='';
       
       $offercat = $this->Home_model->get_data('offercat',array('show'=>1));
       if($offercat) {
           foreach($offercat as $offercat){
                $data['mocat'][$offercat->id] = $offercat->offercat;         
                $data['offercat'] .= '<option value="'.$offercat->id.'"';
                if($offercat->id==$this->session->userdata('likecat'))$data['offercat'] .=' selected="selected "';
                $data['offercat'] .= ' >'.$offercat->offercat.'</option>';
               
               
           }
       } 
       
       $offertype = $this->Home_model->get_data('offertype',array('show'=>1));      
       if($offertype){
           foreach($offertype as $offertype){
                $data['motype'][$offertype->id] = $offertype->type; 
               $ooffer_type .= '<option value="'.$offertype->id.'"';
               if($offertype->id==$this->session->userdata('offertype')) $ooffer_type .=' selected="selected "';
               $ooffer_type .= '>'.$offertype->type.'</option>';
           }
       }
       $country = $this->Home_model->get_data('country',array('show'=>1));
       if($country){
           foreach($country as $country){
               $ocountry .= '<option value="'.$country->id.'"';
               if($country->id==$this->session->userdata('likecountry'))$ocountry .= ' selected="selected "';
               $ocountry .=  '>'.$country->keycode. ' | ' .$country->country.'</option>';
           }
       }
       $data['country'] = $ocountry;
       $data['offertype'] = $ooffer_type;
       $content =$this->load->view('home_offer',$data); 

      
       
      
   }
   function ip(){
      echo '<pre>';
      print_r($_SERVER);
   }
   function phantrang(){
    $this->load->library('pagination');
    $config['base_url'] = base_url().$this->uri->segment(1).'/'.$this->uri->segment(2).'/';
    $config['total_rows'] = $this->total_rows;
    $config['per_page'] = $this->per_page;
    $config['uri_segment'] = 3;
    $config['num_links'] = 6;
    $config['first_link'] = '<<';
    $config['first_tag_open'] = '<li class="firt_pag">';//div cho chu <<
    $config['first_tag_close'] = '</li>';//div cho chu <<
    $config['last_link'] = '>>';
    $config['last_tag_open'] = '<li class="last_pag">';
    $config['last_tag_close'] = '</li>';
    //-------next-
    $config['next_link'] = '&gt;';
    $config['next_tag_open'] = '<li>';
    $config['next_tag_close'] = '</li>';
    //------------preview
    $config['prev_link'] = '&lt;';
    $config['prev_tag_open'] = '<li>';
    $config['prev_tag_close'] = '</li>';
   // ------------------cu?npage
    $config['cur_tag_open'] = '<li class="current">';
    $config['cur_tag_close'] = '</li>';
    //--so 
    $config['num_tag_open'] = '<li>';
    $config['num_tag_close'] = '</li>';
    $this->pagination->initialize($config);
}

    
    
    

    //////////////////tét
    



    //////////////////////////tetst
    
  
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */