<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Payments extends CI_Controller {   
   
    private $mensenger='';    
    private $per_page = 30;
    public $total_rows = 6;   
    public $pub_config= '';
    public $member = '';
    public $member_info = '';
    private $pagina_uri_seg =3;
    private $pagina_baseurl = 's';
    
    function  __construct(){
        parent::__construct();
        //$this->load->model('Home_model'); 
       // $this->inic->sysm();
        //$this->setting=$this->Home_model->get_one('setting',array('id'=>1));
        $this->pagina_baseurl =  base_url().$this->uri->segment(1).'/'.$this->uri->segment(2).'/';
        $this->pub_config= unserialize(file_get_contents('setting_file/publisher.txt'));
        if($this->session->userdata('logedin')){
            $this->member=$this->Home_model->get_one('users',array('id'=>$this->session->userdata('userid')));
            $this->member_info = unserialize($this->member->mailling);
        }elseif($this->uri->segment(3)!='in'&&$this->uri->segment(3)!='up'){
            redirect('v2/sign/in');            
        }
        
       // $this->setting= unserialize(file_get_contents('setting_file/setting.txt'));
        //$this->Home_model->get_one('users',array('id'=>$this->session->userdata('userid')));
        
    }
    function index(){
        echo 1234;
        //$this->account();
    }
    function payment_list(){     
        $this->db->where('usersid',$this->member->id);
        //layas payment owr bangw invoice- không dùng bảng payment
        $data['payment']= $this->db->order_by('id','DESC')->get('invoice')->result();        
        $content =$this->load->view('payments/listpm.php',$data,true); 
        $this->load->view('default/vindex.php',array('content'=>$content)); 
    }
    function request_payouts(){
        $point = floatval($this->input->post('amount'));
        $notes = $this->input->post('notes');
        if(empty($notes))$notes = 'Request payouts';
        $uid = $this->member->id;
        $date = date("Y-m-d H:i:s"); 
        if($uid && $point>0){
            if($point>floatval($this->member->available))$point=floatval($this->member->available);
            //$this->db->trans_start();
                 $this->db->where('id',$uid);            
                 $this->db->set('available', "available - $point", FALSE);
                 $this->db->set('pending', "pending + $point", FALSE);
                 $this->db->set('log', "invoice: $date - $point");
                 $this->db->update('users');
                 if($this->db->affected_rows()>0){
                     $this->db->insert('invoice',array(
                         'status'=>'Pending',
                         'amount'=>$point,
                         'note'=>$notes,
                         'usersid'=>$uid,
                         'date'=>$date,
                         'type'=>3
                     ));
                 }
         //$this->db->trans_complete();
        }

        redirect(base_url('v2/payments'));

    }
}