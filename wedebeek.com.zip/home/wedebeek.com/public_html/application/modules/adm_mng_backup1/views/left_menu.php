<div class="col-sm-1 col-xs-1 col-md-2 menuleft">
   <ul class="nav nav-pills nav-stacked main-menu">
      <li role="presentation">
         <a href="<?php echo base_url($this->config->item('manager'));?>">
         <span class="glyphicon glyphicon-home"></span>
         <span class="hidden-xs hidden-sm">Home</span>
         </a>
      </li>
      <li>
         <a href="<?php echo base_url($this->config->item('manager').'/users');?>">
         <span class="glyphicon glyphicon-user"></span>
         <span class="hidden-xs hidden-sm">Users</span>
         </a>
      </li>
      <li>
      <a href="<?php echo base_url('mng_report');?>">
            <span class="glyphicon glyphicon-search"></span>
            <span class="hidden-xs hidden-sm">Report</span>
        </a>
    </li>
 
   </ul>
</div>
