
<?php 
include('filter.php');
if(!empty($data)){?>
<div class="row" id="list_offers">
   <div class="_2JyLbpIPgPwI6RhYP28lbl mt-3">
      <div class="_12e1_3IHEVbMTMaTUzZ7r9">
         <table role="table" class="table">
            <thead>
               <tr role="row">
                  <th colspan="1" role="columnheader">&nbsp;<span></span></th>
                  <th colspan="2" role="columnheader">Traffic<span></span></th>
                  <th colspan="1" role="columnheader">&nbsp;<span></span></th>
                  <th colspan="1" role="columnheader">&nbsp;<span></span></th>
                  <th colspan="1" role="columnheader">&nbsp;<span></span></th>
                  <th colspan="1" role="columnheader">&nbsp;<span></span></th>
               </tr>
               <tr role="row">
                  <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Date<span></span></th>
                  <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Hosts<span></span></th>
                  <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Hits<span></span></th>
                  <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Impressions<span></span></th>
                  <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Conversions<span></span></th>
                  <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Finances<span></span></th>
                  <th colspan="1" role="columnheader" title="Toggle SortBy" style="cursor: pointer;">Declined<span></span></th>
               </tr>
            </thead>
            <tbody role="rowgroup">
               <?php
                  $thosts = $tclick = $tlead = $treve=$tdec=0;
                  if(!empty($data)){                        
                     foreach($data as $data){
                        $thosts +=$data->hosts;
                        $tclick += $data->click;
                        $tlead += $data->lead;
                        $treve +=$data->reve;
                        $tdec +=$data->declined;
                        $date = date("Y-m-d",strtotime($data->date));
                        echo '
                        <tr role="row" id="data-'.$date .'">
                           <td role="cell">
                              <span class="_1zXei-ymiJr9KAeJboeM6O _1YEl4yCJEz0C3EFWAe9CjL _1A7x8Dsq9xJ42jp0XvuAMJ">
                                 <span>'.$date .'</span>
                                 <span class="_3VArGBZ75OLy7Cl2ijVA1d icon_plus" id="'.$date .'">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon_congtru">
                                       <line x1="12" y1="5" x2="12" y2="19"></line>
                                       <line x1="5" y1="12" x2="19" y2="12"></line>                                          
                                    </svg>
                                 </span>
                              </span>
                           </td>
                           <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>'.$data->hosts.'</span></span></td>
                           <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>'.$data->click.'</span></span></td>
                           <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>'.$data->click.'</span></span></td>
                           <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI">
                              <a  href="'.base_url('/v2/statistics/conversions').'">
                                 '.$data->lead.'
                                 </a>
                              
                           </td>
                           <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$'.number_format(round($data->reve,2),2).'</span></span></td>
                           <td role="cell"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>'.$data->declined.'</span></span></td>
                        </tr>
                        ';
                     }
                  }
                  ?>
              
            </tbody>
            <tfoot>
               <tr>
                  <td colspan="1">Total</td>
                  <td colspan="1"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span><?php echo $thosts;?></span></span></td>
                  <td colspan="1"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span><?php echo $tclick;?></span></span></td>
                  <td colspan="1"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span><?php echo $tclick;?></span></span></td>
                  <td colspan="1">
                     <div class="vfMk5_UxQXI9UPIwF1yqG">
                        <a class="_3HJFBHwnlFb4c_d31FZhBy _2WYuGVXe0FBr9Ni6eMd-pM" href="<?php echo base_url('/v2/statistics/conversions');?>">
                        <?php echo $tlead;?>
                        </a>
                     </div>
                  </td>
                  <td colspan="1"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span>$<?php echo number_format(round($treve,2),2);?></span></span></td>     
                  <td colspan="1"><span class="_1zXei-ymiJr9KAeJboeM6O _2qzGcj9CQQHZm8SCJRN_wI"><span><?php echo $tdec;?></span></span></td>             
               </tr>
            </tfoot>
         </table>
      </div>
   </div>
</div>
<?php }else{
   echo '
   <div clas="col-12 d-flex">
   <div class="sc-hMFtBS JjGPM mt-3"><p class="sc-cLQEGU fdNgUv">There are no stats data</p><svg xmlns="http://www.w3.org/2000/svg" width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class=""><path d="M22.61 16.95A5 5 0 0 0 18 10h-1.26a8 8 0 0 0-7.05-6M5 5a8 8 0 0 0 4 15h9a5 5 0 0 0 1.7-.3"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg></div>
   </div>
   ';
}?>

      
