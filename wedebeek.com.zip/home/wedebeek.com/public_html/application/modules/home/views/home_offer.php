
<style>
       table {
	border-collapse: collapse;
	border-spacing: 0;
    width:100% !important;
}
.center span{
    display:block;
    text-align:center;
}
.sTable .progress{    
    height:10px;
    background:#dedede;
    border:1px solid #cacaca;
    margin-bottom:8px;
    margin-top:2px;
}
    .offer_view a{
        color:#2b6893;
        line-height:19px;
    }
.sTable thead td { text-align: left; }
.sTable thead td { border-bottom: 1px solid #cbcbcb; border-left: 1px solid #cbcbcb; background: #efefef  repeat-x; color: #878787; font-size: 11px; color: #878787; font-weight: normal; padding: 3px 0 1px 3px; }

.sTable2 thead td { text-align: left; }
.sTable2 thead td { border-bottom: 1px solid #cbcbcb; border-left: 1px solid #cbcbcb; background: #efefef  repeat-x; color: #878787; font-size: 11px; color: #878787; font-weight: normal; padding: 3px 0 1px 3px; }


.sTable tbody tr {border-top: 1px solid #e4e4e4;}
.sTable tbody tr:nth-child(even) {background-color: #f6f6f6;}

.sTable tbody td { border-left: 1px solid #e4e4e4; padding: 1px 3px; vertical-align: middle; }
.sTable tbody td:first-child { border-left: none; }
.sTable tbody tr:first-child { border-top: none; }
    
 
   .campaign_click {
   cursor: pointer;
   }
   .chzn-results {
   max-height: 450px !important;
   }
   .status_-1 {
   color: #f57c79 !important;
   }
   .status_-1 td img {
   opacity: .5;
   }
   .status_-1 td a {
   color: #bed1df !important;
   }
   .status_-1 td a span {
   color: #ff9696 !important;
   }
   .status_0 {
   color: #d6b8b8 !important;
   }
   .status_0 td img {
   opacity: .5;
   }
   .status_0 td a {
   color: #bed1df !important;
   }
   .status_0 td a span {
   color: #ff9696 !important;
   }
   .status_1 {
   color: orange !important;
   }
   div.checker {
   float: none !important;
   }
   .disabled_offer td {
   background-color: #FFD4D4 !important;
   }
   .global_offer td {
   background-color: #DCC9FE;
   }
   .capped_offer td {
   background-color: #F6FF94;
   }
   .webStatsLink {
   font-size: 14px;
   }
</style>


  
   <style>
      .occ{white-space: nowrap; font-weight:bold; border-radius: 3px; padding:3px 4px 3px; text-shadow: 0 0 3px #000; background-color: #2fc881; vertical-align: text-bottom; font-size:10px; color:white;}
   </style>
   <!-- Widgets -->
   <div class="widgets table-responsive">
      
         <style>
            .tc{
            white-space: nowrap; font-weight:bold; border-radius: 3px; padding:3px 4px 3px; text-shadow: 0 0 3px #000;
            vertical-align: text-bottom; font-size:10px; color:white;text-align:center;
            }
            .offers .tipIMG{
            cursor:pointer; width:75px; height: 56px;
            border:0;
            }
            .offers a{
            line-height: 19px;
            }
            .imof img{
            vertical-align: text-bottom; cursor:crosshair;border:0;
            padding-right:2px;
            }
            .imof span{
            color: #595959; font-size: 9px;
            }
            .oo{color:white;text-align:center}
         </style>
         <h3 class="oo">Our Offer</h3>
         <table style="font-size:13px;" cellpadding="0" cellspacing="0" class="sTable " id="table_campaigns">
            <thead>
               <tr>
                  
                  
                  <td class="sortCol" width="78">
                     <div>Image<span></span>
                     </div>
                  </td>
                  <td class="sortCol">
                     <div>Title/Description<span></span>
                     </div>
                  </td>
                  <td class="sortCol">
                     <div><span>Geos</span>
                     </div>
                  </td>
                  <td class="sortCol" width="80">
                     <div>Payout<span></span>
                     </div>
                  </td>

                  <td class="sortCol" width="110">
                     <div>Performance<span></span>
                     </div>
                  </td>
                  
                  
                  <td class="sortCol" width="80">
                     <div>Net CR<span></span>
                     </div>
                  </td>
                  <td class="sortCol" width="80">
                     <div>Net EPC<span></span>
                     </div>
                  </td>
                  
               </tr>
            </thead>
            <tbody>
               <?php 
                  if(!empty($offer)){
                      $t=0;
                    
                    //xuwr lys country
                    $mct[0]= $mnct[0] = "";
                    $ct = $this->db->get('country')->result();
                    foreach($ct as $ct){
                        $mct[$ct->id] = $ct->keycode;
                        $mnct[$ct->id] = $ct->country;
                    }
                    //end xuwr ly mang country
                    
                    
                  
                  
                      foreach ($offer as $offer){
                          //xu ly flag country
                        $country =$imgoff= '';
                        if($offer->country){
                            $country = array_filter(explode('o',trim($offer->country)));   
                            if($country){
                                foreach($country as $country){
                                    if($country=='all'){
                                        $imgoff .= '<img src="'.base_url('temp/default/images/globe.png').'">';
                                    }else{
                                        $imgoff .= '<img src="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.4.3/flags/4x3/'.strtolower(trim($mct[$country])).'.svg">';
                                    }
                                    
                                }
                            }                                       
                        
                        }
                        //end xuw ly f;lag country
                  
                          ///
                          if($offer->click){
                            $epc=($offer->point*$offer->lead*100)/$offer->click;
                            $epc =  number_format(round($epc,2),2);
                              
                          }else{
                            
                            $epc =  $cr= '0.00';
                          }
                          $t = strtotime($offer->created);
                          //thêm class disabled_offer vào <tr id="offer_27549" class="offers">
                          echo 
                          '
                          <tr id="offer_27549" class="offers">
                          
                          <td class="center">
                              <span style="display:none;">1</span>
                              <a rel="offers_list2[ajax]" href="'.base_url('v2').'" title="View Links/Creatives.">
                                  <img class="lazy tipIMG" title="" src="'.$offer->img.'" data-original="'.$offer->img.'">
                              </a>
                          </td>
                          <td>
                              <div  class="imof">
                                  <a rel="" href="'.base_url('v2').'" title="View Links/Creatives.">
                                      <strong>'.$offer->title.'</strong>
                  
                                      
                  
                                      <br/>
                                      <span>
                                      '.$offer->description.'
                                      </span>
                                  </a>
                              </div>
                          </td>
                          <td class="center">
                              <span style="font-weight:bold; color:green;">
                              '.$imgoff.'</span>
                          </td>
                          <td class="center">
                              <span style="font-weight:bold; color:green;">
                                  $'.number_format($offer->point,2).'</span>
                          </td>

                          <td class="center">
                            <div class="progress">
                                <div class="progress-bar progress-bar-warning progress-bar-striped" role="progressbar"
                                aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:'.($epc*10).'%">
                                    
                                </div>
                                </div>
                                
                                <div class="progress">
                                <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar"
                                aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:'.($epc*15).'%">
                                    
                                </div>
                            </div>
                          </td>
                          
                          <td class="center" style="color:#00A5FF;">
                            <span>
                             '.$epc.'%
                             </span>
                          </td>
                          <td class="center">
                              <span style="cursor:crosshair; color:#73008c;" title="Network Wide EPC<br/>(Last 4 Days)" class="tipS">
                                  $'.$epc.'
                              </span>
                          </td>
                         
                      </tr>
                          ';
                          
                          
                      }
                  }
                  
                  ?>
            </tbody>
         </table>
     
     
      <div class="clear"></div>
   </div>
